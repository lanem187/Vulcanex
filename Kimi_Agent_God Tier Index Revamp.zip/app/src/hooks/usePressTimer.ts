import { useCallback, useRef, useEffect, useState } from 'react';
import type { PressState } from '@/types';

interface UsePressTimerProps {
  pressNum: 1 | 2;
  press: PressState;
  job: { mat: string; sz: number } | null;
  onUpdate: (updates: Partial<PressState> | ((prev: PressState) => PressState)) => void;
  onComplete: () => void;
  onTick?: (remaining: number, progress: number) => void;
}

export function usePressTimer({
  press,
  job,
  onUpdate,
  onComplete,
  onTick,
}: UsePressTimerProps) {
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const [isWarning, setIsWarning] = useState(false);

  const clearPressInterval = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  }, []);

  const start = useCallback(() => {
    if (press.run || !press.jobId) return;

    onUpdate({ run: true, done: false, el: 0 });
    setIsWarning(false);

    intervalRef.current = setInterval(() => {
      const newEl = press.el + 1;
      const remaining = press.dur - newEl;
      const progress = (newEl / press.dur) * 100;

      // Warning at 10 seconds remaining
      if (remaining <= 10 && remaining > 0) {
        setIsWarning(true);
      }

      onTick?.(remaining, progress);

      if (remaining <= 0) {
        clearPressInterval();
        onComplete();
      } else {
        onUpdate({ el: newEl });
      }
    }, 1000);
  }, [press.run, press.jobId, press.dur, press.el, onUpdate, onComplete, onTick, clearPressInterval]);

  const reset = useCallback(() => {
    clearPressInterval();
    setIsWarning(false);
    
    // Restore timer to job duration if job is loaded
    let dur = 240;
    if (job) {
      dur = 240; // Default, will be set by parent
    }
    
    onUpdate({
      run: false,
      done: false,
      el: 0,
      dur,
    });
  }, [clearPressInterval, job, onUpdate]);

  const stop = useCallback(() => {
    clearPressInterval();
    onUpdate({ run: false });
  }, [clearPressInterval, onUpdate]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      clearPressInterval();
    };
  }, [clearPressInterval]);

  const remaining = press.dur - press.el;
  const progress = (press.el / press.dur) * 100;
  const timeDisplay = press.done 
    ? 'DONE' 
    : `${Math.floor(remaining / 60)}:${String(remaining % 60).padStart(2, '0')}`;

  return {
    start,
    reset,
    stop,
    remaining,
    progress,
    timeDisplay,
    isWarning,
  };
}
