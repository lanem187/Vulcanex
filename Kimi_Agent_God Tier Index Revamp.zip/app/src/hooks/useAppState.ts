import { useState, useEffect, useCallback } from 'react';
import type { 
  AppState, Job, PressState, PressLogEntry, ScrapEntry, 
  CalcEntry, HandoffEntry, Part, Material, CordSize, RefType 
} from '@/types';

const DEFAULT_PARTS: Part[] = [
  { num: '009001-000100', mat: 'Buna', sz: 4, md: 10.0, desc: 'Standard shaft seal' },
  { num: '009001-000150', mat: 'Buna', sz: 5, md: 15.0, desc: 'Hydraulic piston seal' },
  { num: '009001-000200', mat: 'Buna', sz: 6, md: 20.0, desc: 'Face seal' },
  { num: '009002-000120', mat: 'EPDM', sz: 4, md: 12.0, desc: 'Water resistant service' },
  { num: '009002-000180', mat: 'EPDM', sz: 5, md: 18.0, desc: 'Steam service' },
  { num: '009002-000250', mat: 'EPDM', sz: 6, md: 25.0, desc: 'Outdoor / UV service' },
  { num: '009003-000100', mat: 'Viton', sz: 4, md: 10.0, desc: 'Chemical resistant' },
  { num: '009003-000160', mat: 'Viton', sz: 5, md: 16.0, desc: 'High temp service' },
  { num: '009003-000220', mat: 'Viton', sz: 6, md: 22.0, desc: 'Fuel / oil service' },
];

const createDefaultPress = (): PressState => ({
  run: false,
  done: false,
  el: 0,
  dur: 240,
  mat: '',
  sz: '',
  jobId: null,
});

const createDefaultState = (): AppState => ({
  presses: { 1: createDefaultPress(), 2: createDefaultPress() },
  pLog: [],
  jobs: [],
  scrap: [],
  calc: [],
  handoffs: [],
  inv: {},
  parts: [...DEFAULT_PARTS],
  stats: { out: 0, cyc: 0, mat: { Viton: 0, Buna: 0, EPDM: 0 } },
  act: [],
  refType: 'vessel',
});

const STORAGE_KEY = 'vulcanex-v6';

export function useAppState() {
  const [state, setState] = useState<AppState>(createDefaultState());
  const [isLoaded, setIsLoaded] = useState(false);

  // Load from localStorage on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        // Reset any stuck in-progress jobs
        if (parsed.jobs) {
          parsed.jobs = parsed.jobs.map((j: Job) => 
            j.status === 'in-progress' ? { ...j, status: 'pending', pressNum: undefined } : j
          );
        }
        setState(prev => ({ ...prev, ...parsed }));
      }
      // Initialize inventory
      const materials: Material[] = ['Viton', 'Buna', 'EPDM'];
      const sizes: CordSize[] = [4, 5, 6];
      setState(prev => {
        const inv = { ...prev.inv };
        materials.forEach(m => sizes.forEach(s => {
          const key = `${m}-${s}`;
          if (inv[key] === undefined) inv[key] = 0;
        }));
        return { ...prev, inv };
      });
    } catch (e) {
      console.error('Failed to load state:', e);
    }
    setIsLoaded(true);
  }, []);

  // Save to localStorage on changes
  useEffect(() => {
    if (isLoaded) {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
      } catch (e) {
        console.error('Failed to save state:', e);
      }
    }
  }, [state, isLoaded]);

  // Press actions
  const updatePress = useCallback((pressNum: 1 | 2, updates: Partial<PressState>) => {
    setState(prev => ({
      ...prev,
      presses: {
        ...prev.presses,
        [pressNum]: { ...prev.presses[pressNum], ...updates },
      },
    }));
  }, []);

  const addPressLogEntry = useCallback((entry: PressLogEntry) => {
    setState(prev => ({
      ...prev,
      pLog: [entry, ...prev.pLog].slice(0, 60),
    }));
  }, []);

  const deletePressLogEntry = useCallback((index: number) => {
    setState(prev => ({
      ...prev,
      pLog: prev.pLog.filter((_, i) => i !== index),
    }));
  }, []);

  // Job actions
  const addJob = useCallback((job: Omit<Job, 'id' | 'cyclesDone' | 'status'>) => {
    const newJob: Job = {
      ...job,
      id: Date.now(),
      cyclesDone: 0,
      status: 'pending',
    };
    setState(prev => ({
      ...prev,
      jobs: [...prev.jobs, newJob],
    }));
    return newJob;
  }, []);

  const updateJob = useCallback((jobId: number, updates: Partial<Job>) => {
    setState(prev => ({
      ...prev,
      jobs: prev.jobs.map(j => j.id === jobId ? { ...j, ...updates } : j),
    }));
  }, []);

  const removeJob = useCallback((jobId: number) => {
    setState(prev => ({
      ...prev,
      jobs: prev.jobs.filter(j => j.id !== jobId),
    }));
  }, []);

  // Scrap actions
  const addScrap = useCallback((entry: Omit<ScrapEntry, 'date' | 'time'>) => {
    const now = new Date();
    const newEntry: ScrapEntry = {
      ...entry,
      date: now.toISOString().slice(0, 10),
      time: `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`,
    };
    setState(prev => ({
      ...prev,
      scrap: [newEntry, ...prev.scrap],
    }));
  }, []);

  const deleteScrap = useCallback((index: number) => {
    setState(prev => ({
      ...prev,
      scrap: prev.scrap.filter((_, i) => i !== index),
    }));
  }, []);

  // Calc actions
  const addCalc = useCallback((calc: Omit<CalcEntry, 'time'>) => {
    const now = new Date();
    const newEntry: CalcEntry = {
      ...calc,
      time: `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`,
    };
    setState(prev => ({
      ...prev,
      calc: [newEntry, ...prev.calc].slice(0, 30),
    }));
  }, []);

  // Handoff actions
  const addHandoff = useCallback((body: string) => {
    const now = new Date();
    const newEntry: HandoffEntry = {
      date: now.toISOString().slice(0, 10),
      time: `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`,
      body,
    };
    setState(prev => ({
      ...prev,
      handoffs: [newEntry, ...prev.handoffs],
    }));
  }, []);

  // Inventory actions
  const updateInventory = useCallback((key: string, value: number) => {
    setState(prev => ({
      ...prev,
      inv: { ...prev.inv, [key]: value },
    }));
  }, []);

  // Part actions
  const addPart = useCallback((part: Omit<Part, 'num'> & { num: string }) => {
    setState(prev => ({
      ...prev,
      parts: [...prev.parts, part],
    }));
  }, []);

  // Stats actions
  const incrementStat = useCallback((key: 'out' | 'cyc', amount: number = 1) => {
    setState(prev => ({
      ...prev,
      stats: {
        ...prev.stats,
        [key]: prev.stats[key] + amount,
      },
    }));
  }, []);

  const incrementMaterialStat = useCallback((mat: Material, amount: number = 1) => {
    setState(prev => ({
      ...prev,
      stats: {
        ...prev.stats,
        mat: {
          ...prev.stats.mat,
          [mat]: (prev.stats.mat[mat] || 0) + amount,
        },
      },
    }));
  }, []);

  // Activity actions
  const addActivity = useCallback((message: string) => {
    const now = new Date();
    const ts = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    setState(prev => ({
      ...prev,
      act: [`[${ts}] ${message}`, ...prev.act].slice(0, 30),
    }));
  }, []);

  // Ref type
  const setRefType = useCallback((refType: RefType) => {
    setState(prev => ({ ...prev, refType }));
  }, []);

  // Clear actions
  const clearCategory = useCallback((key: keyof AppState) => {
    setState(prev => {
      if (key === 'jobs') {
        // Only remove jobs not on press
        const onPress = [prev.presses[1].jobId, prev.presses[2].jobId];
        return {
          ...prev,
          jobs: prev.jobs.filter(j => onPress.includes(j.id)),
        };
      }
      return { ...prev, [key]: Array.isArray(prev[key]) ? [] : prev[key] };
    });
  }, []);

  const clearAll = useCallback(() => {
    setState(createDefaultState());
  }, []);

  return {
    state,
    isLoaded,
    updatePress,
    addPressLogEntry,
    deletePressLogEntry,
    addJob,
    updateJob,
    removeJob,
    addScrap,
    deleteScrap,
    addCalc,
    addHandoff,
    updateInventory,
    addPart,
    incrementStat,
    incrementMaterialStat,
    addActivity,
    setRefType,
    clearCategory,
    clearAll,
  };
}
