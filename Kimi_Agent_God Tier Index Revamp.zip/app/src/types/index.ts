// VULCANEX Types - Fil-Trek Production Intelligence

export type Material = 'Viton' | 'Buna' | 'EPDM';
export type CordSize = 4 | 5 | 6;
export type Priority = 'normal' | 'urgent' | 'rush';
export type JobStatus = 'pending' | 'in-progress' | 'delayed' | 'done';
export type RefType = 'vessel' | 'sales';
export type PressResult = 'cycle' | 'redo' | 'delayed' | 'complete';

export interface Job {
  id: number;
  refType: RefType;
  ref: string;
  part: string;
  mat: Material;
  sz: CordSize;
  md: number | null;
  qty: number;
  pri: Priority;
  cut: string | null;
  pt: number | null;
  status: JobStatus;
  cyclesDone: number;
  pressNum?: number | string;
  delayReason?: string;
}

export interface PressState {
  run: boolean;
  done: boolean;
  el: number;
  dur: number;
  mat: Material | '';
  sz: CordSize | '';
  jobId: number | null;
}

export interface PressLogEntry {
  time: string;
  press: number;
  ref: string;
  mat: Material | string;
  sz: string;
  dur: string;
  res: PressResult;
}

export interface ScrapEntry {
  date: string;
  time: string;
  press: string;
  mat: Material;
  sz: string;
  ref: string;
  reason: string;
}

export interface CalcEntry {
  time: string;
  md: number;
  sz: CordSize;
  mat: Material;
  cut: string;
  pt: number | null;
}

export interface HandoffEntry {
  date: string;
  time: string;
  body: string;
}

export interface Part {
  num: string;
  mat: Material;
  sz: CordSize;
  md: number | null;
  desc: string;
}

export interface AppState {
  presses: {
    1: PressState;
    2: PressState;
  };
  pLog: PressLogEntry[];
  jobs: Job[];
  scrap: ScrapEntry[];
  calc: CalcEntry[];
  handoffs: HandoffEntry[];
  inv: Record<string, number>;
  parts: Part[];
  stats: {
    out: number;
    cyc: number;
    mat: Record<Material, number>;
  };
  act: string[];
  refType: RefType;
}

export const PRESS_TIMES: Record<Material, Record<CordSize, number>> = {
  Viton: { 4: 240, 5: 300, 6: 360 },
  Buna: { 4: 240, 5: 300, 6: 360 },
  EPDM: { 4: 180, 5: 240, 6: 300 },
};

export const PART_PREFIXES: Record<Material, string> = {
  Buna: '009001',
  EPDM: '009002',
  Viton: '009003',
};

export const MATERIAL_COLORS: Record<Material, { bg: string; text: string; border: string; glow: string }> = {
  Viton: { 
    bg: 'bg-orange-500/10', 
    text: 'text-orange-500', 
    border: 'border-orange-500/30',
    glow: 'shadow-orange-500/20'
  },
  Buna: { 
    bg: 'bg-sky-500/10', 
    text: 'text-sky-500', 
    border: 'border-sky-500/30',
    glow: 'shadow-sky-500/20'
  },
  EPDM: { 
    bg: 'bg-emerald-500/10', 
    text: 'text-emerald-500', 
    border: 'border-emerald-500/30',
    glow: 'shadow-emerald-500/20'
  },
};
