import { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Trash2 } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import type { AppState, Job, Material, CordSize, Priority, RefType } from '@/types';
import { PRESS_TIMES, PART_PREFIXES } from '@/types';

interface JobQueueProps {
  state: AppState;
  notify: (message: string, type?: 'success' | 'error' | 'warning' | 'info') => void;
  addJob: (job: Omit<Job, 'id' | 'cyclesDone' | 'status'>) => void;
  removeJob: (jobId: number) => void;
  setRefType: (refType: RefType) => void;
}

const priorityColors: Record<Priority, string> = {
  rush: 'text-rose-400 border-rose-500/30 bg-rose-500/10',
  urgent: 'text-amber-400 border-amber-500/30 bg-amber-500/10',
  normal: 'text-[#7a7a96] border-[#3d3d55] bg-transparent',
};

const statusColors: Record<Job['status'], string> = {
  pending: 'text-[#7a7a96] border-[#3d3d55] bg-transparent',
  'in-progress': 'text-orange-400 border-orange-500/30 bg-orange-500/10',
  delayed: 'text-amber-400 border-amber-500/30 bg-amber-500/10',
  done: 'text-emerald-400 border-emerald-500/30 bg-emerald-500/10',
};

export function JobQueue({ state, notify, addJob, removeJob, setRefType }: JobQueueProps) {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [refType, setLocalRefType] = useState<RefType>(state.refType);
  const [formData, setFormData] = useState({
    ref: '',
    part: '',
    mat: 'Buna' as Material,
    sz: 4 as CordSize,
    md: '',
    qty: '',
    pri: 'normal' as Priority,
  });

  const handleSubmit = () => {
    if (!formData.ref) {
      notify(`Enter a ${refType === 'vessel' ? 'vessel number' : 'sales order'}`, 'warning');
      return;
    }
    if (!formData.qty || Number(formData.qty) < 1) {
      notify('Enter a valid quantity', 'warning');
      return;
    }

    const md = parseFloat(formData.md);
    const cut = !isNaN(md) && md > 0 ? (md * Math.PI).toFixed(2) : null;
    const pt = PRESS_TIMES[formData.mat][formData.sz];

    addJob({
      refType,
      ref: formData.ref,
      part: formData.part || `${PART_PREFIXES[formData.mat]}-${String(Date.now()).slice(-6)}`,
      mat: formData.mat,
      sz: formData.sz,
      md: !isNaN(md) ? md : null,
      qty: Number(formData.qty),
      pri: formData.pri,
      cut,
      pt,
    });

    notify('Job added to queue', 'success');
    setDialogOpen(false);
    setFormData({
      ref: '',
      part: '',
      mat: 'Buna',
      sz: 4,
      md: '',
      qty: '',
      pri: 'normal',
    });
  };

  const handleRefTypeChange = (type: RefType) => {
    setLocalRefType(type);
    setRefType(type);
  };

  // Sort jobs by priority
  const sortedJobs = [...state.jobs].sort((a, b) => {
    const priorityOrder = { rush: 0, urgent: 1, normal: 2 };
    return priorityOrder[a.pri] - priorityOrder[b.pri];
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="font-display text-xl tracking-wider text-[#7a7a96]">JOB QUEUE</h2>
        <Button
          onClick={() => setDialogOpen(true)}
          className="bg-orange-500 hover:bg-orange-600 text-white"
        >
          <Plus className="w-4 h-4 mr-2" />
          ADD JOB
        </Button>
      </div>

      {/* Job List */}
      <div className="space-y-2">
        {sortedJobs.length === 0 ? (
          <Card className="bg-gradient-to-br from-[#0a0a0f] to-[#101018] border-[#1e1e2e]">
            <CardContent className="py-12 text-center">
              <p className="font-mono text-[11px] text-[#3d3d55]">No jobs in queue.</p>
            </CardContent>
          </Card>
        ) : (
          sortedJobs.map((job, index) => {
            const isDone = job.status === 'done';
            const isDelayed = job.status === 'delayed';
            const isInProgress = job.status === 'in-progress';

            return (
              <motion.div
                key={job.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <Card className={`bg-gradient-to-br from-[#0a0a0f] to-[#101018] border-[#1e1e2e] transition-all duration-200 ${
                  isInProgress ? 'border-orange-500/30 bg-orange-500/5' :
                  isDelayed ? 'border-amber-500/30 bg-amber-500/5' :
                  isDone ? 'opacity-50' : ''
                }`}>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-4">
                      {/* Job Number */}
                      <div className="font-display text-xl text-[#3d3d55] w-8 text-center">
                        {index + 1}
                      </div>

                      {/* Job Info */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-[9px] text-[#3d3d55] uppercase tracking-wider">
                            {job.refType === 'vessel' ? 'VES' : 'SO'}
                          </span>
                          <span className="font-mono text-sm font-bold text-[#f0f0f5]">{job.ref}</span>
                          <span className="font-mono text-[10px] text-[#7a7a96]">{job.part}</span>
                        </div>
                        <div className="flex items-center gap-2 mt-1 flex-wrap">
                          <Badge className={`${
                            job.mat === 'Viton' ? 'bg-orange-500/10 text-orange-400 border-orange-500/30' :
                            job.mat === 'Buna' ? 'bg-sky-500/10 text-sky-400 border-sky-500/30' :
                            'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                          } border font-mono text-[9px]`}>
                            {job.mat}
                          </Badge>
                          <span className="font-mono text-[10px] text-[#7a7a96]">{job.sz}mm</span>
                          {job.cut && (
                            <span className="font-mono text-[10px] text-orange-400">
                              Cut: {job.cut}"
                            </span>
                          )}
                          {job.pt && (
                            <span className="font-mono text-[10px] text-[#7a7a96]">{job.pt}s</span>
                          )}
                          <Badge variant="outline" className={`${priorityColors[job.pri]} font-mono text-[9px] uppercase`}>
                            {job.pri}
                          </Badge>
                          <Badge variant="outline" className={`${statusColors[job.status]} font-mono text-[9px] uppercase`}>
                            {job.status === 'in-progress' ? `ON PRESS ${job.pressNum}` : job.status}
                          </Badge>
                          {isDelayed && job.delayReason && (
                            <span className="font-mono text-[10px] text-[#7a7a96]">
                              — {job.delayReason}
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Quantity */}
                      <div className="text-right hidden sm:block">
                        <div className="font-display text-2xl text-[#f0f0f5]">{job.qty}</div>
                        <div className="font-mono text-[9px] text-[#3d3d55] uppercase">pcs</div>
                      </div>

                      {/* Actions */}
                      <div>
                        {!isDone && !isInProgress ? (
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => {
                              removeJob(job.id);
                              notify('Job removed', 'success');
                            }}
                            className="text-[#3d3d55] hover:text-rose-400 hover:bg-rose-500/10"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        ) : (
                          <div className="w-10" />
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })
        )}
      </div>

      {/* Add Job Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="bg-[#0a0a0f] border-[#1e1e2e] max-w-lg">
          <DialogHeader>
            <DialogTitle className="font-display text-xl text-[#f0f0f5] tracking-wider">
              ADD JOB
            </DialogTitle>
            <DialogDescription className="font-mono text-sm text-[#7a7a96]">
              Add a new job to the production queue.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 pt-4">
            {/* Reference Type Toggle */}
            <div className="space-y-2">
              <Label className="font-mono text-[10px] tracking-wider text-[#7a7a96] uppercase">
                Reference Type
              </Label>
              <div className="flex gap-2">
                <Button
                  type="button"
                  variant={refType === 'vessel' ? 'default' : 'outline'}
                  onClick={() => handleRefTypeChange('vessel')}
                  className={`flex-1 font-mono text-[10px] tracking-wider ${
                    refType === 'vessel' 
                      ? 'bg-orange-500 hover:bg-orange-600 text-white' 
                      : 'border-[#2a2a3d] text-[#7a7a96] hover:text-[#f0f0f5]'
                  }`}
                >
                  Vessel No.
                </Button>
                <Button
                  type="button"
                  variant={refType === 'sales' ? 'default' : 'outline'}
                  onClick={() => handleRefTypeChange('sales')}
                  className={`flex-1 font-mono text-[10px] tracking-wider ${
                    refType === 'sales' 
                      ? 'bg-orange-500 hover:bg-orange-600 text-white' 
                      : 'border-[#2a2a3d] text-[#7a7a96] hover:text-[#f0f0f5]'
                  }`}
                >
                  Sales Order
                </Button>
              </div>
            </div>

            {/* Reference & Part Number */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label className="font-mono text-[10px] tracking-wider text-[#7a7a96] uppercase">
                  {refType === 'vessel' ? 'Vessel Number' : 'Sales Order'}
                </Label>
                <Input
                  value={formData.ref}
                  onChange={(e) => setFormData({ ...formData, ref: e.target.value })}
                  placeholder={refType === 'vessel' ? 'VES-0001' : 'SO-0001'}
                  className="bg-[#16161f] border-[#2a2a3d] text-[#f0f0f5] font-mono text-sm"
                />
              </div>
              <div className="space-y-2">
                <Label className="font-mono text-[10px] tracking-wider text-[#7a7a96] uppercase">
                  Part Number
                </Label>
                <Input
                  value={formData.part}
                  onChange={(e) => setFormData({ ...formData, part: e.target.value })}
                  placeholder="009001-000100"
                  className="bg-[#16161f] border-[#2a2a3d] text-[#f0f0f5] font-mono text-sm"
                />
              </div>
            </div>

            {/* Material & Size */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label className="font-mono text-[10px] tracking-wider text-[#7a7a96] uppercase">
                  Material
                </Label>
                <Select
                  value={formData.mat}
                  onValueChange={(v) => setFormData({ ...formData, mat: v as Material })}
                >
                  <SelectTrigger className="bg-[#16161f] border-[#2a2a3d] text-[#f0f0f5] font-mono text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-[#16161f] border-[#2a2a3d]">
                    <SelectItem value="Viton" className="text-[#f0f0f5]">Viton</SelectItem>
                    <SelectItem value="Buna" className="text-[#f0f0f5]">Buna</SelectItem>
                    <SelectItem value="EPDM" className="text-[#f0f0f5]">EPDM</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="font-mono text-[10px] tracking-wider text-[#7a7a96] uppercase">
                  Cord Size
                </Label>
                <Select
                  value={String(formData.sz)}
                  onValueChange={(v) => setFormData({ ...formData, sz: Number(v) as CordSize })}
                >
                  <SelectTrigger className="bg-[#16161f] border-[#2a2a3d] text-[#f0f0f5] font-mono text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-[#16161f] border-[#2a2a3d]">
                    <SelectItem value="4" className="text-[#f0f0f5]">4mm</SelectItem>
                    <SelectItem value="5" className="text-[#f0f0f5]">5mm</SelectItem>
                    <SelectItem value="6" className="text-[#f0f0f5]">6mm</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* MD & Quantity */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label className="font-mono text-[10px] tracking-wider text-[#7a7a96] uppercase">
                  MD (inches)
                </Label>
                <Input
                  type="number"
                  step="0.01"
                  min="0"
                  value={formData.md}
                  onChange={(e) => setFormData({ ...formData, md: e.target.value })}
                  placeholder="24.625"
                  className="bg-[#16161f] border-[#2a2a3d] text-[#f0f0f5] font-mono text-sm"
                />
              </div>
              <div className="space-y-2">
                <Label className="font-mono text-[10px] tracking-wider text-[#7a7a96] uppercase">
                  Quantity
                </Label>
                <Input
                  type="number"
                  min="1"
                  value={formData.qty}
                  onChange={(e) => setFormData({ ...formData, qty: e.target.value })}
                  placeholder="100"
                  className="bg-[#16161f] border-[#2a2a3d] text-[#f0f0f5] font-mono text-sm"
                />
              </div>
            </div>

            {/* Priority */}
            <div className="space-y-2">
              <Label className="font-mono text-[10px] tracking-wider text-[#7a7a96] uppercase">
                Priority
              </Label>
              <Select
                value={formData.pri}
                onValueChange={(v) => setFormData({ ...formData, pri: v as Priority })}
              >
                <SelectTrigger className="bg-[#16161f] border-[#2a2a3d] text-[#f0f0f5] font-mono text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[#16161f] border-[#2a2a3d]">
                  <SelectItem value="normal" className="text-[#f0f0f5]">Normal</SelectItem>
                  <SelectItem value="urgent" className="text-[#f0f0f5]">Urgent</SelectItem>
                  <SelectItem value="rush" className="text-[#f0f0f5]">Rush</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Submit */}
            <Button
              onClick={handleSubmit}
              className="w-full bg-orange-500 hover:bg-orange-600 text-white"
            >
              ADD TO QUEUE
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
