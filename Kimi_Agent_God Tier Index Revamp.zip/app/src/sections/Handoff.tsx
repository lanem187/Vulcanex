import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Send, Printer, FileDown, ClipboardList } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import type { AppState } from '@/types';

interface HandoffProps {
  state: AppState;
  notify: (message: string, type?: 'success' | 'error' | 'warning' | 'info') => void;
  addHandoff: (body: string) => void;
}

export function Handoff({ state, notify, addHandoff }: HandoffProps) {
  const [notes, setNotes] = useState('');

  const summary = useMemo(() => {
    const today = new Date().toISOString().slice(0, 10);
    const todayScrap = state.scrap.filter(s => s.date === today);
    const doneJobs = state.jobs.filter(j => j.status === 'done');
    const delayedJobs = state.jobs.filter(j => j.status === 'delayed');
    const totalPieces = state.stats.out + state.scrap.length;
    const scrapRate = totalPieces > 0 ? ((state.scrap.length / totalPieces) * 100).toFixed(1) : '0';
    const pendingJobs = state.jobs.filter(j => j.status === 'pending' || j.status === 'delayed');

    const lines: string[] = [];
    lines.push(`DATE: ${today}  |  SHIFT: Day (07:30-16:30)`);
    lines.push('');
    lines.push('-- PRODUCTION --');
    lines.push(`Total O-rings completed:  ${state.stats.out}`);
    lines.push(`Press cycles run:         ${state.stats.cyc}`);
    lines.push(`Jobs completed:           ${doneJobs.length} of ${state.jobs.length}`);
    if (delayedJobs.length > 0) {
      lines.push(`Jobs delayed:             ${delayedJobs.length} (require follow-up)`);
    }
    lines.push('');
    lines.push('-- MATERIAL OUTPUT --');
    lines.push(`Viton:  ${state.stats.mat.Viton || 0} pcs`);
    lines.push(`Buna:   ${state.stats.mat.Buna || 0} pcs`);
    lines.push(`EPDM:   ${state.stats.mat.EPDM || 0} pcs`);
    lines.push('');
    lines.push('-- QUALITY --');
    lines.push(`Splice failures:          ${state.scrap.length} total, ${todayScrap.length} today`);
    lines.push(`Failure rate:             ${scrapRate}%`);
    lines.push('');
    lines.push('-- PENDING / DELAYED JOBS FOR NEXT SHIFT --');
    if (pendingJobs.length > 0) {
      pendingJobs.forEach(j => {
        const tag = `${j.refType === 'vessel' ? 'VES' : 'SO'}: ${j.ref}`;
        const delayed = j.status === 'delayed' ? ` DELAYED: ${j.delayReason}` : '';
        lines.push(`  * ${tag} (${j.part}) -- ${j.mat} ${j.sz}mm x ${j.qty} pcs [${j.pri.toUpperCase()}]${delayed}`);
      });
    } else {
      lines.push('  None.');
    }

    return lines.join('\n');
  }, [state]);

  const handleSubmit = () => {
    const fullBody = notes.trim() ? `${summary}\n\n-- TECH NOTES --\n${notes}` : summary;
    addHandoff(fullBody);
    setNotes('');
    notify('Handoff submitted', 'success');
  };

  const handlePrint = () => {
    const content = `${summary}\n\nNOTES:\n${notes || '(none)'}`;
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>VULCANEX Handoff</title>
            <style>
              body { font-family: monospace; font-size: 13px; padding: 24px; line-height: 1.8; background: #fff; color: #111; }
              pre { white-space: pre-wrap; }
            </style>
          </head>
          <body>
            <pre>${content.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</pre>
          </body>
        </html>
      `);
      printWindow.document.close();
      printWindow.focus();
      setTimeout(() => printWindow.print(), 300);
    }
  };

  const exportPDF = () => {
    window.print();
    notify('PDF export initiated', 'info');
  };

  return (
    <div className="space-y-6">
      <h2 className="font-display text-xl tracking-wider text-[#7a7a96]">SHIFT HANDOFF REPORT</h2>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Left Column - Summary & Notes */}
        <div className="space-y-4">
          {/* Auto-Generated Summary */}
          <Card className="bg-gradient-to-br from-[#0a0a0f] to-[#101018] border-[#1e1e2e]">
            <CardHeader>
              <CardTitle className="font-display text-sm tracking-wider text-[#7a7a96]">
                AUTO-GENERATED SUMMARY
              </CardTitle>
            </CardHeader>
            <CardContent>
              <pre className="font-mono text-[11px] text-[#7a7a96] leading-relaxed whitespace-pre-wrap overflow-x-auto">
                {summary}
              </pre>
            </CardContent>
          </Card>

          {/* Additional Notes */}
          <Card className="bg-gradient-to-br from-[#0a0a0f] to-[#101018] border-[#1e1e2e]">
            <CardHeader>
              <CardTitle className="font-display text-sm tracking-wider text-[#7a7a96]">
                ADDITIONAL NOTES
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Equipment issues, material concerns, instructions for next shift..."
                className="bg-[#16161f] border-[#2a2a3d] text-[#f0f0f5] font-mono text-sm min-h-[120px] resize-y"
              />
              <div className="flex flex-wrap gap-2">
                <Button
                  onClick={handleSubmit}
                  className="bg-orange-500 hover:bg-orange-600 text-white"
                >
                  <Send className="w-4 h-4 mr-2" />
                  SUBMIT HANDOFF
                </Button>
                <Button
                  variant="outline"
                  onClick={handlePrint}
                  className="border-[#2a2a3d] text-[#7a7a96] hover:text-[#f0f0f5] hover:bg-[#16161f]"
                >
                  <Printer className="w-4 h-4 mr-2" />
                  PRINT
                </Button>
                <Button
                  variant="outline"
                  onClick={exportPDF}
                  className="border-amber-500/30 text-amber-400 hover:bg-amber-500/10"
                >
                  <FileDown className="w-4 h-4 mr-2" />
                  EXPORT PDF
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Column - Previous Handoffs */}
        <div>
          <Card className="bg-gradient-to-br from-[#0a0a0f] to-[#101018] border-[#1e1e2e] h-full">
            <CardHeader>
              <CardTitle className="font-display text-sm tracking-wider text-[#7a7a96]">
                PREVIOUS HANDOFFS
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 max-h-[600px] overflow-y-auto scrollbar-thin">
                {state.handoffs.length === 0 ? (
                  <div className="text-center py-12">
                    <ClipboardList className="w-12 h-12 text-[#3d3d55] mx-auto mb-3" />
                    <p className="font-mono text-[11px] text-[#3d3d55]">
                      No previous handoffs on record.
                    </p>
                  </div>
                ) : (
                  state.handoffs.map((handoff, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.05 }}
                      className="bg-[#101018] border border-[#1e1e2e] rounded-lg p-4 border-l-2 border-l-orange-500"
                    >
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant="outline" className="font-mono text-[9px] border-[#2a2a3d] text-[#7a7a96]">
                          {handoff.date}
                        </Badge>
                        <Badge variant="outline" className="font-mono text-[9px] border-[#2a2a3d] text-[#7a7a96]">
                          {handoff.time}
                        </Badge>
                        <span className="font-mono text-[9px] text-[#3d3d55]">Day Shift</span>
                      </div>
                      <pre className="font-mono text-[11px] text-[#f0f0f5] leading-relaxed whitespace-pre-wrap">
                        {handoff.body}
                      </pre>
                    </motion.div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
