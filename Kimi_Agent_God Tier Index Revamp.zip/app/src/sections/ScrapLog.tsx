import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { AlertTriangle, Plus, Trash2, TrendingUp, Calendar } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import type { AppState, Material } from '@/types';

interface ScrapLogProps {
  state: AppState;
  notify: (message: string, type?: 'success' | 'error' | 'warning' | 'info') => void;
  addScrap: (entry: { press: string; mat: Material; sz: string; ref: string; reason: string }) => void;
  deleteScrap: (index: number) => void;
}

export function ScrapLog({ state, notify, addScrap, deleteScrap }: ScrapLogProps) {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    press: '1',
    mat: 'Viton' as Material,
    sz: '4',
    ref: '',
    reason: '',
  });

  const stats = useMemo(() => {
    const today = new Date().toISOString().slice(0, 10);
    const todayScrap = state.scrap.filter(s => s.date === today);
    const totalPieces = state.stats.out + state.scrap.length;
    const rate = totalPieces > 0 ? ((state.scrap.length / totalPieces) * 100).toFixed(1) : '0';
    
    return {
      total: state.scrap.length,
      today: todayScrap.length,
      rate,
    };
  }, [state.scrap, state.stats.out]);

  const handleSubmit = () => {
    addScrap({
      press: formData.press,
      mat: formData.mat,
      sz: `${formData.sz}mm`,
      ref: formData.ref,
      reason: formData.reason || 'Not specified',
    });

    notify('Splice failure logged', 'error');
    setDialogOpen(false);
    setFormData({
      press: '1',
      mat: 'Viton',
      sz: '4',
      ref: '',
      reason: '',
    });
  };

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="bg-gradient-to-br from-[#0a0a0f] to-[#101018] border-[#1e1e2e]">
          <CardContent className="p-4 text-center">
            <div className="font-display text-4xl text-rose-400">{stats.total}</div>
            <div className="font-mono text-[9px] tracking-wider text-[#7a7a96] uppercase mt-1">
              Total Failures
            </div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-[#0a0a0f] to-[#101018] border-[#1e1e2e]">
          <CardContent className="p-4 text-center">
            <div className="font-display text-4xl text-amber-400">{stats.rate}%</div>
            <div className="font-mono text-[9px] tracking-wider text-[#7a7a96] uppercase mt-1">
              Failure Rate
            </div>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-[#0a0a0f] to-[#101018] border-[#1e1e2e]">
          <CardContent className="p-4 text-center">
            <div className="font-display text-4xl text-rose-400">{stats.today}</div>
            <div className="font-mono text-[9px] tracking-wider text-[#7a7a96] uppercase mt-1">
              Today
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Header & Add Button */}
      <div className="flex items-center justify-between">
        <h2 className="font-display text-xl tracking-wider text-[#7a7a96]">SPLICE FAILURE LOG</h2>
        <Button
          onClick={() => setDialogOpen(true)}
          variant="outline"
          className="border-rose-500/30 text-rose-400 hover:bg-rose-500/10"
        >
          <Plus className="w-4 h-4 mr-2" />
          LOG FAILURE
        </Button>
      </div>

      {/* Scrap Table */}
      <Card className="bg-gradient-to-br from-[#0a0a0f] to-[#101018] border-[#1e1e2e]">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#1e1e2e]">
                  <th className="text-left py-3 px-4 font-mono text-[9px] tracking-[0.2em] text-[#7a7a96] uppercase">Date / Time</th>
                  <th className="text-left py-3 px-4 font-mono text-[9px] tracking-[0.2em] text-[#7a7a96] uppercase">Press</th>
                  <th className="text-left py-3 px-4 font-mono text-[9px] tracking-[0.2em] text-[#7a7a96] uppercase">Material</th>
                  <th className="text-left py-3 px-4 font-mono text-[9px] tracking-[0.2em] text-[#7a7a96] uppercase">Size</th>
                  <th className="text-left py-3 px-4 font-mono text-[9px] tracking-[0.2em] text-[#7a7a96] uppercase">Reference</th>
                  <th className="text-left py-3 px-4 font-mono text-[9px] tracking-[0.2em] text-[#7a7a96] uppercase">Reason</th>
                  <th className="text-left py-3 px-4 font-mono text-[9px] tracking-[0.2em] text-[#7a7a96] uppercase"></th>
                </tr>
              </thead>
              <tbody>
                {state.scrap.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-12 text-center">
                      <div className="flex flex-col items-center gap-2">
                        <TrendingUp className="w-8 h-8 text-emerald-500" />
                        <span className="font-mono text-[11px] text-[#3d3d55]">
                          No failures logged. Keep it that way.
                        </span>
                      </div>
                    </td>
                  </tr>
                ) : (
                  state.scrap.map((entry, i) => {
                    const matChar = entry.mat.toLowerCase().charAt(0);
                    return (
                      <motion.tr
                        key={i}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: i * 0.03 }}
                        className="border-b border-[#1e1e2e]/50 hover:bg-[#16161f]/50 transition-colors"
                      >
                        <td className="py-3 px-4 font-mono text-[11px] text-[#f0f0f5]">
                          <div className="flex items-center gap-2">
                            <Calendar className="w-3 h-3 text-[#3d3d55]" />
                            {entry.date} {entry.time}
                          </div>
                        </td>
                        <td className="py-3 px-4 font-mono text-[11px] text-[#f0f0f5]">Press {entry.press}</td>
                        <td className="py-3 px-4">
                          <Badge className={`${
                            matChar === 'v' ? 'bg-orange-500/10 text-orange-400 border-orange-500/30' :
                            matChar === 'b' ? 'bg-sky-500/10 text-sky-400 border-sky-500/30' :
                            'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                          } border font-mono text-[9px]`}>
                            {entry.mat}
                          </Badge>
                        </td>
                        <td className="py-3 px-4 font-mono text-[11px] text-[#f0f0f5]">{entry.sz}</td>
                        <td className="py-3 px-4 font-mono text-[11px] text-[#f0f0f5]">{entry.ref}</td>
                        <td className="py-3 px-4 font-mono text-[11px] text-[#7a7a96]">{entry.reason}</td>
                        <td className="py-3 px-4">
                          <button
                            onClick={() => {
                              deleteScrap(i);
                              notify('Failure entry removed', 'success');
                            }}
                            className="text-[#3d3d55] hover:text-rose-400 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </motion.tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Add Failure Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="bg-[#0a0a0f] border-[#1e1e2e]">
          <DialogHeader>
            <DialogTitle className="font-display text-xl text-rose-400 tracking-wider flex items-center gap-2">
              <AlertTriangle className="w-5 h-5" />
              LOG FAILURE
            </DialogTitle>
            <DialogDescription className="font-mono text-sm text-[#7a7a96]">
              Record a splice failure for quality tracking.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 pt-4">
            {/* Press & Material */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label className="font-mono text-[10px] tracking-wider text-[#7a7a96] uppercase">
                  Press
                </Label>
                <Select
                  value={formData.press}
                  onValueChange={(v) => setFormData({ ...formData, press: v })}
                >
                  <SelectTrigger className="bg-[#16161f] border-[#2a2a3d] text-[#f0f0f5] font-mono text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-[#16161f] border-[#2a2a3d]">
                    <SelectItem value="1" className="text-[#f0f0f5]">Press 1</SelectItem>
                    <SelectItem value="2" className="text-[#f0f0f5]">Press 2</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="font-mono text-[10px] tracking-wider text-[#7a7a96] uppercase">
                  Material
                </Label>
                <Select
                  value={formData.mat}
                  onValueChange={(v) => setFormData({ ...formData, mat: v as Material })}
                >
                  <SelectTrigger className="bg-[#16161f] border-[#2a2a3d] text-[#f0f0f5] font-mono text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-[#16161f] border-[#2a2a3d]">
                    <SelectItem value="Viton" className="text-[#f0f0f5]">Viton</SelectItem>
                    <SelectItem value="Buna" className="text-[#f0f0f5]">Buna</SelectItem>
                    <SelectItem value="EPDM" className="text-[#f0f0f5]">EPDM</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Size & Reference */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label className="font-mono text-[10px] tracking-wider text-[#7a7a96] uppercase">
                  Cord Size
                </Label>
                <Select
                  value={formData.sz}
                  onValueChange={(v) => setFormData({ ...formData, sz: v })}
                >
                  <SelectTrigger className="bg-[#16161f] border-[#2a2a3d] text-[#f0f0f5] font-mono text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-[#16161f] border-[#2a2a3d]">
                    <SelectItem value="4" className="text-[#f0f0f5]">4mm</SelectItem>
                    <SelectItem value="5" className="text-[#f0f0f5]">5mm</SelectItem>
                    <SelectItem value="6" className="text-[#f0f0f5]">6mm</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="font-mono text-[10px] tracking-wider text-[#7a7a96] uppercase">
                  Reference (optional)
                </Label>
                <Input
                  value={formData.ref}
                  onChange={(e) => setFormData({ ...formData, ref: e.target.value })}
                  placeholder="VES-0001 or SO-0001"
                  className="bg-[#16161f] border-[#2a2a3d] text-[#f0f0f5] font-mono text-sm"
                />
              </div>
            </div>

            {/* Reason */}
            <div className="space-y-2">
              <Label className="font-mono text-[10px] tracking-wider text-[#7a7a96] uppercase">
                Reason
              </Label>
              <Input
                value={formData.reason}
                onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
                placeholder="e.g. Splice didn't hold, short cut..."
                className="bg-[#16161f] border-[#2a2a3d] text-[#f0f0f5] font-mono text-sm"
              />
            </div>

            {/* Submit */}
            <Button
              onClick={handleSubmit}
              className="w-full bg-rose-500/10 border border-rose-500/30 text-rose-400 hover:bg-rose-500/20"
            >
              LOG FAILURE
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
