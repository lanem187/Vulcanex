import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Save, History } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import type { AppState, Material, CordSize } from '@/types';
import { PRESS_TIMES } from '@/types';

interface CutLengthCalcProps {
  state: AppState;
  notify: (message: string, type?: 'success' | 'error' | 'warning' | 'info') => void;
  addCalc: (calc: { md: number; sz: CordSize; mat: Material; cut: string; pt: number | null }) => void;
}

export function CutLengthCalc({ state, notify, addCalc }: CutLengthCalcProps) {
  const [md, setMd] = useState('');
  const [sz, setSz] = useState<CordSize>(4);
  const [mat, setMat] = useState<Material>('Viton');

  const cutLength = useMemo(() => {
    const mdNum = parseFloat(md);
    if (isNaN(mdNum) || mdNum <= 0) return null;
    return (mdNum * Math.PI).toFixed(3);
  }, [md]);

  const pressTime = useMemo(() => {
    return PRESS_TIMES[mat][sz];
  }, [mat, sz]);

  const handleSave = () => {
    const mdNum = parseFloat(md);
    if (isNaN(mdNum) || mdNum <= 0) {
      notify('Enter an MD value first', 'warning');
      return;
    }

    addCalc({
      md: mdNum,
      sz,
      mat,
      cut: cutLength!,
      pt: pressTime,
    });

    notify('Calculation saved', 'success');
  };

  return (
    <div className="space-y-6">
      <h2 className="font-display text-xl tracking-wider text-[#7a7a96]">CUT LENGTH CALCULATOR</h2>

      {/* Calculator Card */}
      <Card className="bg-gradient-to-br from-[#0a0a0f] to-[#101018] border-[#1e1e2e]">
        <CardHeader>
          <CardTitle className="font-mono text-[10px] tracking-wider text-[#7a7a96] uppercase">
            FORMULA: CUT LENGTH = MD × π | MD = MEAN DIAMETER IN INCHES | e.g. 24.625" × π = 77.32"
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Input Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
            {/* MD Input */}
            <div className="space-y-2">
              <Label className="font-mono text-[10px] tracking-wider text-[#7a7a96] uppercase">
                MD (inches)
              </Label>
              <Input
                type="number"
                step="0.01"
                min="0"
                value={md}
                onChange={(e) => setMd(e.target.value)}
                placeholder="e.g. 24.625"
                className="bg-[#16161f] border-[#2a2a3d] text-[#f0f0f5] font-mono text-lg"
              />
            </div>

            {/* Cord Size */}
            <div className="space-y-2">
              <Label className="font-mono text-[10px] tracking-wider text-[#7a7a96] uppercase">
                Cord Size
              </Label>
              <Select value={String(sz)} onValueChange={(v) => setSz(Number(v) as CordSize)}>
                <SelectTrigger className="bg-[#16161f] border-[#2a2a3d] text-[#f0f0f5] font-mono">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[#16161f] border-[#2a2a3d]">
                  <SelectItem value="4" className="text-[#f0f0f5]">4mm</SelectItem>
                  <SelectItem value="5" className="text-[#f0f0f5]">5mm</SelectItem>
                  <SelectItem value="6" className="text-[#f0f0f5]">6mm</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Material */}
            <div className="space-y-2">
              <Label className="font-mono text-[10px] tracking-wider text-[#7a7a96] uppercase">
                Material
              </Label>
              <Select value={mat} onValueChange={(v) => setMat(v as Material)}>
                <SelectTrigger className="bg-[#16161f] border-[#2a2a3d] text-[#f0f0f5] font-mono">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[#16161f] border-[#2a2a3d]">
                  <SelectItem value="Viton" className="text-[#f0f0f5]">Viton</SelectItem>
                  <SelectItem value="Buna" className="text-[#f0f0f5]">Buna</SelectItem>
                  <SelectItem value="EPDM" className="text-[#f0f0f5]">EPDM</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Result Card */}
            <div className="bg-[#16161f] border border-orange-500/30 rounded-lg p-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="font-mono text-[9px] tracking-wider text-[#7a7a96] uppercase mb-1">
                    Cut Length
                  </div>
                  <div className="font-display text-2xl text-orange-400 tracking-wider">
                    {cutLength ? `${cutLength}"` : '--'}
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-mono text-[9px] tracking-wider text-[#7a7a96] uppercase mb-1">
                    Press Time
                  </div>
                  <div className="font-display text-xl text-orange-300 tracking-wider">
                    {pressTime}s
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Save Button */}
          <Button
            onClick={handleSave}
            disabled={!cutLength}
            className="bg-orange-500 hover:bg-orange-600 text-white disabled:opacity-30"
          >
            <Save className="w-4 h-4 mr-2" />
            SAVE CALCULATION
          </Button>
        </CardContent>
      </Card>

      {/* History */}
      <Card className="bg-gradient-to-br from-[#0a0a0f] to-[#101018] border-[#1e1e2e]">
        <CardHeader>
          <CardTitle className="font-display text-lg tracking-wider text-[#7a7a96] flex items-center gap-2">
            <History className="w-5 h-5" />
            HISTORY
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#1e1e2e]">
                  <th className="text-left py-2 px-3 font-mono text-[9px] tracking-[0.2em] text-[#7a7a96] uppercase">Time</th>
                  <th className="text-left py-2 px-3 font-mono text-[9px] tracking-[0.2em] text-[#7a7a96] uppercase">MD</th>
                  <th className="text-left py-2 px-3 font-mono text-[9px] tracking-[0.2em] text-[#7a7a96] uppercase">Cord</th>
                  <th className="text-left py-2 px-3 font-mono text-[9px] tracking-[0.2em] text-[#7a7a96] uppercase">Material</th>
                  <th className="text-left py-2 px-3 font-mono text-[9px] tracking-[0.2em] text-[#7a7a96] uppercase">Cut Length</th>
                  <th className="text-left py-2 px-3 font-mono text-[9px] tracking-[0.2em] text-[#7a7a96] uppercase">Press Time</th>
                </tr>
              </thead>
              <tbody>
                {state.calc.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center font-mono text-[10px] text-[#3d3d55]">
                      No calculations saved yet.
                    </td>
                  </tr>
                ) : (
                  state.calc.map((calc, i) => {
                    const matChar = calc.mat.toLowerCase().charAt(0);
                    return (
                      <motion.tr
                        key={i}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: i * 0.03 }}
                        className="border-b border-[#1e1e2e]/50 hover:bg-[#16161f]/50 transition-colors"
                      >
                        <td className="py-2 px-3 font-mono text-[11px] text-[#f0f0f5]">{calc.time}</td>
                        <td className="py-2 px-3 font-mono text-[11px] text-[#f0f0f5]">{calc.md}"</td>
                        <td className="py-2 px-3 font-mono text-[11px] text-[#f0f0f5]">{calc.sz}mm</td>
                        <td className="py-2 px-3">
                          <Badge className={`${
                            matChar === 'v' ? 'bg-orange-500/10 text-orange-400 border-orange-500/30' :
                            matChar === 'b' ? 'bg-sky-500/10 text-sky-400 border-sky-500/30' :
                            'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                          } border font-mono text-[9px]`}>
                            {calc.mat}
                          </Badge>
                        </td>
                        <td className="py-2 px-3 font-mono text-[11px] text-orange-400 font-bold">{calc.cut}"</td>
                        <td className="py-2 px-3 font-mono text-[11px] text-[#f0f0f5]">{calc.pt ? `${calc.pt}s` : '--'}</td>
                      </motion.tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
