import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { 
  CheckCircle2, 
  AlertCircle, 
  TrendingUp, 
  Activity, 
  Trash2, 
  FileDown, 
  RotateCcw,
  AlertTriangle
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import type { AppState, Material } from '@/types';

interface DashboardProps {
  state: AppState;
  notify: (message: string, type?: 'success' | 'error' | 'warning' | 'info') => void;
  addActivity: (message: string) => void;
  clearCategory: (key: keyof AppState) => void;
  clearAll: () => void;
}

const KPICard = ({ 
  title, 
  value, 
  unit, 
  color,
  icon: Icon,
  delay = 0 
}: { 
  title: string; 
  value: string | number; 
  unit: string; 
  color: string;
  icon: React.ElementType;
  delay?: number;
}) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay, duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
  >
    <Card className="bg-gradient-to-br from-[#0a0a0f] to-[#101018] border-[#1e1e2e] overflow-hidden relative group hover:border-[#2a2a3d] transition-colors duration-300">
      <div className={`absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r ${color}`} />
      <div className="absolute top-0 left-0 right-0 h-10 bg-gradient-to-b from-white/[0.02] to-transparent pointer-events-none" />
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2">
          <Icon className="w-4 h-4 text-[#7a7a96]" />
          <span className="font-mono text-[9px] tracking-[0.25em] text-[#7a7a96] uppercase">{title}</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className={`font-display text-4xl sm:text-5xl lg:text-6xl tracking-wider ${color.includes('emerald') ? 'text-emerald-400' : color.includes('rose') ? 'text-rose-400' : color.includes('sky') ? 'text-sky-400' : color.includes('amber') ? 'text-amber-400' : 'text-orange-400'}`}>
          {value}
        </div>
        <div className="font-mono text-[9px] tracking-[0.2em] text-[#3d3d55] uppercase mt-2">
          {unit}
        </div>
      </CardContent>
    </Card>
  </motion.div>
);

interface PressStatusMiniProps {
  pressNum: number;
  press: AppState['presses'][1];
  job: { ref: string; refType: string; mat: string; sz: number } | null;
}

const PressStatusMini = ({ pressNum, press, job }: PressStatusMiniProps) => {
  const getStatus = () => {
    if (press.run) return { label: 'RUNNING', color: 'text-emerald-400 border-emerald-500/30 bg-emerald-500/10', animate: true };
    if (press.done) return { label: 'DONE', color: 'text-emerald-400 border-emerald-500/30 bg-emerald-500/10', animate: false };
    if (press.jobId) return { label: 'LOADED', color: 'text-[#7a7a96] border-[#3d3d55] bg-transparent', animate: false };
    return { label: 'IDLE', color: 'text-[#7a7a96] border-[#3d3d55] bg-transparent', animate: false };
  };

  const status = getStatus();
  const remaining = press.dur - press.el;
  const timeDisplay = press.done 
    ? 'DONE' 
    : press.run 
      ? `${Math.floor(remaining / 60)}:${String(remaining % 60).padStart(2, '0')}`
      : '--:--';

  return (
    <div className="bg-[#101018] border border-[#1e1e2e] rounded-lg p-4">
      <div className="flex items-center justify-between mb-2">
        <span className="font-mono text-[10px] tracking-[0.2em] text-[#7a7a96] uppercase">Press {pressNum}</span>
        <Badge 
          variant="outline" 
          className={`font-mono text-[9px] tracking-wider ${status.color} ${status.animate ? 'animate-pulse' : ''}`}
        >
          {status.label}
        </Badge>
      </div>
      <div className="font-display text-3xl tracking-wider text-[#f0f0f5]">
        {timeDisplay}
      </div>
      <div className="font-mono text-[10px] text-[#7a7a96] mt-1 truncate">
        {job ? `${job.ref} · ${job.mat} ${job.sz}mm` : 'No active job'}
      </div>
    </div>
  );
};

interface MaterialBarProps {
  material: Material;
  value: number;
  max: number;
}

const MaterialBar = ({ material, value, max }: MaterialBarProps) => {
  const percentage = max > 0 ? (value / max) * 100 : 0;

  return (
    <div className="flex items-center gap-3">
      <span className={`font-mono text-[10px] tracking-wider w-14 ${
        material === 'Viton' ? 'text-orange-400' :
        material === 'Buna' ? 'text-sky-400' :
        'text-emerald-400'
      }`}>
        {material.toUpperCase()}
      </span>
      <div className="flex-1 h-2 bg-[#1e1e2e] rounded-full overflow-hidden">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${percentage}%` }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className={`h-full rounded-full ${
            material === 'Viton' ? 'bg-orange-500' : 
            material === 'Buna' ? 'bg-sky-500' : 
            'bg-emerald-500'
          }`}
        />
      </div>
      <span className="font-mono text-[10px] text-[#7a7a96] w-10 text-right">
        {value}
      </span>
    </div>
  );
};

export function Dashboard({ state, notify, clearCategory, clearAll }: DashboardProps) {
  const [clearDialogOpen, setClearDialogOpen] = useState(false);

  const stats = useMemo(() => {
    const doneJobs = state.jobs.filter(j => j.status === 'done').length;
    const totalPieces = state.stats.out + state.scrap.length;
    const scrapRate = totalPieces > 0 ? Math.round((state.scrap.length / totalPieces) * 100) : 0;
    const maxMat = Math.max(1, state.stats.mat.Viton, state.stats.mat.Buna, state.stats.mat.EPDM);
    
    return { doneJobs, scrapRate, maxMat };
  }, [state]);

  const press1Job = state.jobs.find(j => j.id === state.presses[1].jobId) || null;
  const press2Job = state.jobs.find(j => j.id === state.presses[2].jobId) || null;

  const handleClearCategory = (key: keyof AppState, name: string) => {
    clearCategory(key);
    notify(`${name} cleared`, 'success');
  };

  const handleClearAll = () => {
    clearAll();
    setClearDialogOpen(false);
    notify('All data cleared', 'success');
  };

  const exportPDF = () => {
    window.print();
    notify('PDF export initiated', 'info');
  };

  return (
    <div className="space-y-6">
      {/* KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard
          title="Today's Output"
          value={state.stats.out}
          unit="O-RINGS COMPLETED"
          color="from-emerald-500 to-emerald-400"
          icon={CheckCircle2}
          delay={0}
        />
        <KPICard
          title="Scrap Rate"
          value={`${stats.scrapRate}%`}
          unit="SPLICE FAILURES"
          color="from-rose-500 to-rose-400"
          icon={AlertCircle}
          delay={0.1}
        />
        <KPICard
          title="Jobs Done"
          value={`${stats.doneJobs}/${state.jobs.length}`}
          unit="QUEUED"
          color="from-sky-500 to-sky-400"
          icon={TrendingUp}
          delay={0.2}
        />
        <KPICard
          title="Press Cycles"
          value={state.stats.cyc}
          unit="TOTAL TODAY"
          color="from-amber-500 to-amber-400"
          icon={Activity}
          delay={0.3}
        />
      </div>

      {/* Press Status & Material Output */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Press Status */}
        <Card className="bg-gradient-to-br from-[#0a0a0f] to-[#101018] border-[#1e1e2e]">
          <CardHeader>
            <CardTitle className="font-display text-lg tracking-wider text-[#7a7a96]">
              PRESS STATUS
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <PressStatusMini pressNum={1} press={state.presses[1]} job={press1Job} />
            <PressStatusMini pressNum={2} press={state.presses[2]} job={press2Job} />
          </CardContent>
        </Card>

        {/* Material Output */}
        <Card className="bg-gradient-to-br from-[#0a0a0f] to-[#101018] border-[#1e1e2e]">
          <CardHeader>
            <CardTitle className="font-display text-lg tracking-wider text-[#7a7a96]">
              MATERIAL OUTPUT
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <MaterialBar material="Viton" value={state.stats.mat.Viton} max={stats.maxMat} />
            <MaterialBar material="Buna" value={state.stats.mat.Buna} max={stats.maxMat} />
            <MaterialBar material="EPDM" value={state.stats.mat.EPDM} max={stats.maxMat} />
            
            {/* Activity Feed */}
            <div className="mt-6 pt-4 border-t border-[#1e1e2e]">
              <h4 className="font-display text-sm tracking-wider text-[#7a7a96] mb-3">
                ACTIVITY FEED
              </h4>
              <div className="space-y-1.5 max-h-32 overflow-y-auto scrollbar-thin">
                {state.act.length === 0 ? (
                  <span className="font-mono text-[10px] text-[#3d3d55]">No activity yet.</span>
                ) : (
                  state.act.slice(0, 10).map((activity, i) => (
                    <div 
                      key={i} 
                      className={`font-mono text-[10px] ${
                        activity.includes('COMPLETE') ? 'text-emerald-400' :
                        activity.includes('DELAYED') ? 'text-amber-400' :
                        activity.includes('FAIL') ? 'text-rose-400' :
                        'text-[#7a7a96]'
                      }`}
                    >
                      {activity}
                    </div>
                  ))
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Data Management */}
      <Card className="bg-gradient-to-br from-[#0a0a0f] to-[#101018] border-[#1e1e2e]">
        <CardHeader>
          <CardTitle className="font-display text-lg tracking-wider text-[#7a7a96]">
            DATA MANAGEMENT
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="font-mono text-[10px] text-[#7a7a96] mb-4 tracking-wide">
            Remove specific data categories without wiping everything. Individual log entries can be deleted directly in the Press Log and Scrap Log tables.
          </p>
          <div className="flex flex-wrap gap-2">
            {[
              { key: 'pLog', label: 'PRESS LOG' },
              { key: 'scrap', label: 'SCRAP LOG' },
              { key: 'calc', label: 'CALC HISTORY' },
              { key: 'handoffs', label: 'HANDOFFS' },
              { key: 'jobs', label: 'JOB QUEUE' },
              { key: 'act', label: 'ACTIVITY' },
            ].map(({ key, label }) => (
              <Button
                key={key}
                variant="outline"
                size="sm"
                onClick={() => handleClearCategory(key as keyof AppState, label)}
                className="font-mono text-[9px] tracking-wider border-[#2a2a3d] text-[#7a7a96] hover:text-[#f0f0f5] hover:border-[#3d3d55] hover:bg-[#16161f]"
              >
                <RotateCcw className="w-3 h-3 mr-1" />
                CLEAR {label}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Export & Clear All */}
      <div className="flex flex-wrap gap-3">
        <Button
          onClick={exportPDF}
          className="bg-amber-500/10 border border-amber-500/30 text-amber-400 hover:bg-amber-500/20 hover:border-amber-500/50"
        >
          <FileDown className="w-4 h-4 mr-2" />
          EXPORT END-OF-DAY PDF
        </Button>

        <AlertDialog open={clearDialogOpen} onOpenChange={setClearDialogOpen}>
          <AlertDialogTrigger asChild>
            <Button
              variant="outline"
              className="border-rose-500/30 text-rose-400 hover:bg-rose-500/10 hover:border-rose-500/50"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              CLEAR ALL DATA
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent className="bg-[#0a0a0f] border-[#1e1e2e]">
            <AlertDialogHeader>
              <AlertDialogTitle className="font-display text-xl text-rose-400 tracking-wider flex items-center gap-2">
                <AlertTriangle className="w-5 h-5" />
                CLEAR ALL DATA
              </AlertDialogTitle>
              <AlertDialogDescription className="font-mono text-sm text-[#7a7a96]">
                This will permanently delete all jobs, press logs, scrap records, calculations, and handoffs. 
                Your part number list will be preserved. This cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel className="border-[#2a2a3d] text-[#7a7a96] hover:bg-[#16161f]">
                CANCEL
              </AlertDialogCancel>
              <AlertDialogAction
                onClick={handleClearAll}
                className="bg-rose-500/10 border border-rose-500/30 text-rose-400 hover:bg-rose-500/20"
              >
                YES, CLEAR
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}
