import { useState } from 'react';
import { AlertCircle, Save } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import type { AppState, Material, CordSize } from '@/types';

interface InventoryProps {
  state: AppState;
  notify: (message: string, type?: 'success' | 'error' | 'warning' | 'info') => void;
  updateInventory: (key: string, value: number) => void;
}

const LOW_STOCK_THRESHOLD = 50;

interface InventoryItemProps {
  material: Material;
  size: CordSize;
  quantity: number;
  onChange: (value: number) => void;
}

const InventoryItem = ({ material, size, quantity, onChange }: InventoryItemProps) => {
  const isLow = quantity < LOW_STOCK_THRESHOLD;

  return (
    <div className={`relative bg-[#101018] border rounded-lg p-4 overflow-hidden ${
      isLow ? 'border-rose-500/30' : 'border-[#1e1e2e]'
    }`}>
      {/* Bottom accent line */}
      <div className={`absolute bottom-0 left-0 right-0 h-0.5 ${
        material === 'Viton' ? 'bg-orange-500' :
        material === 'Buna' ? 'bg-sky-500' :
        'bg-emerald-500'
      }`} />

      {/* Low stock indicator */}
      {isLow && (
        <div className="absolute top-2 right-2">
          <Badge className="bg-rose-500/10 text-rose-400 border-rose-500/30 font-mono text-[8px] tracking-wider">
            LOW
          </Badge>
        </div>
      )}

      <div className="space-y-2">
        <div className={`font-mono text-[9px] tracking-wider uppercase ${
          material === 'Viton' ? 'text-orange-400' :
          material === 'Buna' ? 'text-sky-400' :
          'text-emerald-400'
        }`}>
          {material}
        </div>
        <div className="font-display text-lg text-[#f0f0f5] tracking-wider">
          {size}mm Cord
        </div>
        <Input
          type="number"
          min="0"
          value={quantity}
          onChange={(e) => onChange(parseInt(e.target.value) || 0)}
          className={`bg-[#16161f] border text-center font-display text-2xl tracking-wider ${
            isLow ? 'border-rose-500/30 text-rose-400' : 'border-[#2a2a3d] text-[#f0f0f5]'
          }`}
        />
        <div className="font-mono text-[8px] text-[#3d3d55] uppercase tracking-wider text-center">
          metres in stock
        </div>
      </div>
    </div>
  );
};

export function Inventory({ state, notify, updateInventory }: InventoryProps) {
  const [localValues, setLocalValues] = useState<Record<string, number>>({});

  const materials: Material[] = ['Viton', 'Buna', 'EPDM'];
  const sizes: CordSize[] = [4, 5, 6];

  const getValue = (material: Material, size: CordSize) => {
    const key = `${material}-${size}`;
    return localValues[key] !== undefined ? localValues[key] : (state.inv[key] || 0);
  };

  const handleChange = (material: Material, size: CordSize, value: number) => {
    const key = `${material}-${size}`;
    setLocalValues(prev => ({ ...prev, [key]: value }));
  };

  const handleSave = () => {
    Object.entries(localValues).forEach(([key, value]) => {
      updateInventory(key, value);
    });
    setLocalValues({});
    notify('Inventory saved', 'success');
  };

  const hasChanges = Object.keys(localValues).length > 0;

  // Calculate low stock items
  const lowStockItems: { material: Material; size: CordSize }[] = [];
  materials.forEach(mat => {
    sizes.forEach(sz => {
      const key = `${mat}-${sz}`;
      const value = localValues[key] !== undefined ? localValues[key] : (state.inv[key] || 0);
      if (value < LOW_STOCK_THRESHOLD) {
        lowStockItems.push({ material: mat, size: sz });
      }
    });
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <h2 className="font-display text-xl tracking-wider text-[#7a7a96]">MATERIAL INVENTORY</h2>
          {lowStockItems.length > 0 && (
            <Badge className="bg-rose-500/10 text-rose-400 border-rose-500/30 font-mono text-[9px]">
              <AlertCircle className="w-3 h-3 mr-1" />
              {lowStockItems.length} LOW
            </Badge>
          )}
        </div>
        <Button
          onClick={handleSave}
          disabled={!hasChanges}
          variant="outline"
          className="border-[#2a2a3d] text-[#7a7a96] hover:text-[#f0f0f5] hover:bg-[#16161f] disabled:opacity-30"
        >
          <Save className="w-4 h-4 mr-2" />
          SAVE ALL
        </Button>
      </div>

      {/* Inventory Grid by Material */}
      <div className="space-y-6">
        {materials.map((material) => (
          <div key={material}>
            <h3 className={`font-display text-sm tracking-wider mb-3 ${
              material === 'Viton' ? 'text-orange-400' :
              material === 'Buna' ? 'text-sky-400' :
              'text-emerald-400'
            }`}>
              {material.toUpperCase()}
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
              {sizes.map((size) => (
                <InventoryItem
                  key={`${material}-${size}`}
                  material={material}
                  size={size}
                  quantity={getValue(material, size)}
                  onChange={(value) => handleChange(material, size, value)}
                />
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Summary */}
      <Card className="bg-gradient-to-br from-[#0a0a0f] to-[#101018] border-[#1e1e2e]">
        <CardHeader>
          <CardTitle className="font-display text-sm tracking-wider text-[#7a7a96]">
            INVENTORY SUMMARY
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {materials.map((material) => {
              const totalStock = sizes.reduce((sum, size) => {
                const key = `${material}-${size}`;
                const value = localValues[key] !== undefined ? localValues[key] : (state.inv[key] || 0);
                return sum + value;
              }, 0);

              return (
                <div key={material} className="bg-[#101018] border border-[#1e1e2e] rounded-lg p-4">
                  <div className={`font-mono text-[9px] tracking-wider uppercase mb-1 ${
                    material === 'Viton' ? 'text-orange-400' :
                    material === 'Buna' ? 'text-sky-400' :
                    'text-emerald-400'
                  }`}>
                    {material}
                  </div>
                  <div className="font-display text-3xl text-[#f0f0f5]">
                    {totalStock.toLocaleString()}
                  </div>
                  <div className="font-mono text-[9px] text-[#3d3d55] uppercase tracking-wider">
                    total metres
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
