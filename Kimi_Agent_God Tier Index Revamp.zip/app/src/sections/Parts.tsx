import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Search, Plus, Package } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import type { AppState, Material, CordSize, Part } from '@/types';
import { PRESS_TIMES } from '@/types';

interface PartsProps {
  state: AppState;
  notify: (message: string, type?: 'success' | 'error' | 'warning' | 'info') => void;
  addPart: (part: Part) => void;
}

export function Parts({ state, notify, addPart }: PartsProps) {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [formData, setFormData] = useState({
    num: '',
    mat: 'Buna' as Material,
    sz: 4 as CordSize,
    md: '',
    desc: '',
  });

  const filteredParts = useMemo(() => {
    const query = searchQuery.toLowerCase();
    return state.parts.filter(part =>
      part.num.toLowerCase().includes(query) ||
      part.mat.toLowerCase().includes(query) ||
      String(part.sz).includes(query) ||
      (part.desc && part.desc.toLowerCase().includes(query))
    );
  }, [state.parts, searchQuery]);

  const handleSubmit = () => {
    if (!formData.num) {
      notify('Enter a part number', 'warning');
      return;
    }

    const md = parseFloat(formData.md);
    
    addPart({
      num: formData.num,
      mat: formData.mat,
      sz: formData.sz,
      md: !isNaN(md) ? md : null,
      desc: formData.desc,
    });

    notify('Part added', 'success');
    setDialogOpen(false);
    setFormData({
      num: '',
      mat: 'Buna',
      sz: 4,
      md: '',
      desc: '',
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <h2 className="font-display text-xl tracking-wider text-[#7a7a96]">PART NUMBER LOOKUP</h2>

      {/* Legend & Search */}
      <Card className="bg-gradient-to-br from-[#0a0a0f] to-[#101018] border-[#1e1e2e]">
        <CardContent className="p-4 space-y-4">
          {/* Legend */}
          <div className="flex flex-wrap gap-4">
            <div className="flex items-center gap-2">
              <span className="font-mono text-[11px] text-orange-400">009003</span>
              <span className="font-mono text-[11px] text-[#7a7a96]">-XXXXXX = Viton</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="font-mono text-[11px] text-sky-400">009001</span>
              <span className="font-mono text-[11px] text-[#7a7a96]">-XXXXXX = Buna</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="font-mono text-[11px] text-emerald-400">009002</span>
              <span className="font-mono text-[11px] text-[#7a7a96]">-XXXXXX = EPDM</span>
            </div>
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#3d3d55]" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search part number, material, size, description..."
              className="pl-10 bg-[#16161f] border-[#2a2a3d] text-[#f0f0f5] font-mono text-sm"
            />
          </div>
        </CardContent>
      </Card>

      {/* Parts List */}
      <Card className="bg-gradient-to-br from-[#0a0a0f] to-[#101018] border-[#1e1e2e]">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#1e1e2e]">
                  <th className="text-left py-3 px-4 font-mono text-[9px] tracking-[0.2em] text-[#7a7a96] uppercase">Part Number</th>
                  <th className="text-left py-3 px-4 font-mono text-[9px] tracking-[0.2em] text-[#7a7a96] uppercase">Description</th>
                  <th className="text-left py-3 px-4 font-mono text-[9px] tracking-[0.2em] text-[#7a7a96] uppercase">Material</th>
                  <th className="text-left py-3 px-4 font-mono text-[9px] tracking-[0.2em] text-[#7a7a96] uppercase">Size</th>
                  <th className="text-left py-3 px-4 font-mono text-[9px] tracking-[0.2em] text-[#7a7a96] uppercase">Cut Length</th>
                  <th className="text-left py-3 px-4 font-mono text-[9px] tracking-[0.2em] text-[#7a7a96] uppercase">Press Time</th>
                </tr>
              </thead>
              <tbody>
                {filteredParts.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-12 text-center">
                      <div className="flex flex-col items-center gap-2">
                        <Package className="w-8 h-8 text-[#3d3d55]" />
                        <span className="font-mono text-[11px] text-[#3d3d55]">
                          {searchQuery ? 'No parts match your search.' : 'No parts found.'}
                        </span>
                      </div>
                    </td>
                  </tr>
                ) : (
                  filteredParts.map((part, i) => {
                    const matChar = part.mat.toLowerCase().charAt(0);
                    const cutLength = part.md ? (part.md * Math.PI).toFixed(3) : '--';
                    const pressTime = PRESS_TIMES[part.mat]?.[part.sz] || '--';

                    return (
                      <motion.tr
                        key={part.num}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: i * 0.02 }}
                        className="border-b border-[#1e1e2e]/50 hover:bg-[#16161f]/50 transition-colors"
                      >
                        <td className="py-3 px-4">
                          <div className="font-mono text-sm font-bold text-[#f0f0f5]">{part.num}</div>
                        </td>
                        <td className="py-3 px-4">
                          <div className="font-mono text-[11px] text-[#7a7a96]">{part.desc || '--'}</div>
                        </td>
                        <td className="py-3 px-4">
                          <Badge className={`${
                            matChar === 'v' ? 'bg-orange-500/10 text-orange-400 border-orange-500/30' :
                            matChar === 'b' ? 'bg-sky-500/10 text-sky-400 border-sky-500/30' :
                            'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                          } border font-mono text-[9px]`}>
                            {part.mat}
                          </Badge>
                        </td>
                        <td className="py-3 px-4">
                          <span className="font-mono text-[11px] text-[#7a7a96]">{part.sz}mm</span>
                        </td>
                        <td className="py-3 px-4">
                          <span className="font-mono text-[11px] text-orange-400">
                            {cutLength !== '--' ? `${cutLength}"` : '--'}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          <span className="font-mono text-[11px] text-[#7a7a96]">
                            {pressTime !== '--' ? `${pressTime}s` : '--'}
                          </span>
                        </td>
                      </motion.tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Add Part Button */}
      <div className="flex justify-end">
        <Button
          onClick={() => setDialogOpen(true)}
          className="bg-orange-500 hover:bg-orange-600 text-white"
        >
          <Plus className="w-4 h-4 mr-2" />
          ADD PART
        </Button>
      </div>

      {/* Add Part Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="bg-[#0a0a0f] border-[#1e1e2e]">
          <DialogHeader>
            <DialogTitle className="font-display text-xl text-[#f0f0f5] tracking-wider">
              ADD PART
            </DialogTitle>
            <DialogDescription className="font-mono text-sm text-[#7a7a96]">
              Add a new part to the database.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 pt-4">
            {/* Part Number & Material */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label className="font-mono text-[10px] tracking-wider text-[#7a7a96] uppercase">
                  Part Number
                </Label>
                <Input
                  value={formData.num}
                  onChange={(e) => setFormData({ ...formData, num: e.target.value })}
                  placeholder="009001-000100"
                  className="bg-[#16161f] border-[#2a2a3d] text-[#f0f0f5] font-mono text-sm"
                />
              </div>
              <div className="space-y-2">
                <Label className="font-mono text-[10px] tracking-wider text-[#7a7a96] uppercase">
                  Material
                </Label>
                <Select
                  value={formData.mat}
                  onValueChange={(v) => setFormData({ ...formData, mat: v as Material })}
                >
                  <SelectTrigger className="bg-[#16161f] border-[#2a2a3d] text-[#f0f0f5] font-mono text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-[#16161f] border-[#2a2a3d]">
                    <SelectItem value="Viton" className="text-[#f0f0f5]">Viton</SelectItem>
                    <SelectItem value="Buna" className="text-[#f0f0f5]">Buna</SelectItem>
                    <SelectItem value="EPDM" className="text-[#f0f0f5]">EPDM</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Size & MD */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label className="font-mono text-[10px] tracking-wider text-[#7a7a96] uppercase">
                  Cord Size
                </Label>
                <Select
                  value={String(formData.sz)}
                  onValueChange={(v) => setFormData({ ...formData, sz: Number(v) as CordSize })}
                >
                  <SelectTrigger className="bg-[#16161f] border-[#2a2a3d] text-[#f0f0f5] font-mono text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-[#16161f] border-[#2a2a3d]">
                    <SelectItem value="4" className="text-[#f0f0f5]">4mm</SelectItem>
                    <SelectItem value="5" className="text-[#f0f0f5]">5mm</SelectItem>
                    <SelectItem value="6" className="text-[#f0f0f5]">6mm</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="font-mono text-[10px] tracking-wider text-[#7a7a96] uppercase">
                  MD (inches)
                </Label>
                <Input
                  type="number"
                  step="0.01"
                  min="0"
                  value={formData.md}
                  onChange={(e) => setFormData({ ...formData, md: e.target.value })}
                  placeholder="24.625"
                  className="bg-[#16161f] border-[#2a2a3d] text-[#f0f0f5] font-mono text-sm"
                />
              </div>
            </div>

            {/* Description */}
            <div className="space-y-2">
              <Label className="font-mono text-[10px] tracking-wider text-[#7a7a96] uppercase">
                Description
              </Label>
              <Input
                value={formData.desc}
                onChange={(e) => setFormData({ ...formData, desc: e.target.value })}
                placeholder="e.g. Standard shaft seal"
                className="bg-[#16161f] border-[#2a2a3d] text-[#f0f0f5] font-mono text-sm"
              />
            </div>

            {/* Submit */}
            <Button
              onClick={handleSubmit}
              className="w-full bg-orange-500 hover:bg-orange-600 text-white"
            >
              ADD PART
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
