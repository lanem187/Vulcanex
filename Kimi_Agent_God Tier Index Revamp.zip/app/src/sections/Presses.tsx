import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Play, 
  RotateCcw, 
  LogOut, 
  SkipForward, 
  Redo, 
  CheckCircle, 
  Pause,
  Trash2
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import type { AppState, Job, PressResult } from '@/types';
import { PRESS_TIMES } from '@/types';

interface PressesProps {
  state: AppState;
  notify: (message: string, type?: 'success' | 'error' | 'warning' | 'info') => void;
  addActivity: (message: string) => void;
  updatePress: (pressNum: 1 | 2, updates: Partial<AppState['presses'][1]>) => void;
  addPressLogEntry: (entry: { time: string; press: number; ref: string; mat: string; sz: string; dur: string; res: PressResult }) => void;
  updateJob: (jobId: number, updates: Partial<Job>) => void;
  incrementStat: (key: 'out' | 'cyc', amount?: number) => void;
  deletePressLogEntry: (index: number) => void;
}

interface PressCardProps {
  pressNum: 1 | 2;
  press: AppState['presses'][1];
  job: Job | null;
  availableJobs: Job[];
  onLoadJob: (jobId: number) => void;
  onUnload: () => void;
  onStart: () => void;
  onReset: () => void;
  onNextCycle: () => void;
  onRedoCycle: () => void;
  onCloseJob: () => void;
  onDelay: (reason: string) => void;
}

const PressCard = ({
  pressNum,
  press,
  job,
  availableJobs,
  onLoadJob,
  onUnload,
  onStart,
  onReset,
  onNextCycle,
  onRedoCycle,
  onCloseJob,
  onDelay,
}: PressCardProps) => {
  const [delayDialogOpen, setDelayDialogOpen] = useState(false);
  const [delayReason, setDelayReason] = useState('');

  const remaining = press.dur - press.el;
  const progress = (press.el / press.dur) * 100;
  
  const timeDisplay = press.done 
    ? 'DONE' 
    : `${Math.floor(remaining / 60)}:${String(remaining % 60).padStart(2, '0')}`;

  const getStatusBadge = () => {
    if (press.run) return { label: 'RUNNING', className: 'text-orange-400 border-orange-500/30 bg-orange-500/10 animate-pulse' };
    if (press.done) return { label: 'DONE', className: 'text-emerald-400 border-emerald-500/30 bg-emerald-500/10' };
    if (press.jobId) return { label: 'LOADED', className: 'text-[#7a7a96] border-[#3d3d55] bg-transparent' };
    return { label: 'IDLE', className: 'text-[#7a7a96] border-[#3d3d55] bg-transparent' };
  };

  const status = getStatusBadge();
  const cycleProgress = job && job.qty > 1 ? ((job.cyclesDone || 0) / job.qty) * 100 : 0;

  const handleDelayConfirm = () => {
    onDelay(delayReason || 'No reason given');
    setDelayDialogOpen(false);
    setDelayReason('');
  };

  return (
    <>
      <Card className={`bg-gradient-to-br from-[#0a0a0f] to-[#101018] border-[#1e1e2e] overflow-hidden transition-all duration-300 ${
        press.run ? 'press-running' : press.done ? 'press-done' : ''
      }`}>
        {/* Header */}
        <CardHeader className="pb-0">
          <div className="flex items-center justify-between">
            <CardTitle className="font-display text-2xl tracking-[0.15em] text-[#f0f0f5]">
              PRESS {pressNum}
            </CardTitle>
            <Badge variant="outline" className={`font-mono text-[9px] tracking-wider ${status.className}`}>
              {status.label}
            </Badge>
          </div>
        </CardHeader>

        <CardContent className="space-y-4 pt-4">
          {/* Job Zone */}
          <div className="bg-[#101018] border border-[#1e1e2e] rounded-lg p-4 min-h-[100px]">
            {!press.jobId ? (
              <div className="space-y-3">
                <p className="font-mono text-[10px] text-[#7a7a96]">No job loaded. Select a pending job:</p>
                <Select onValueChange={(v) => onLoadJob(Number(v))}>
                  <SelectTrigger className="bg-[#16161f] border-[#2a2a3d] text-[#f0f0f5] font-mono text-xs">
                    <SelectValue placeholder="-- select pending job --" />
                  </SelectTrigger>
                  <SelectContent className="bg-[#16161f] border-[#2a2a3d]">
                    {availableJobs.map((j) => {
                      const isShared = j.status === 'in-progress';
                      const isDelayed = j.status === 'delayed';
                      const done = j.cyclesDone || 0;
                      const progressText = j.qty > 1 ? ` (${done}/${j.qty})` : '';
                      const sharedLabel = isShared ? ` [ON PRESS ${j.pressNum}]` : '';
                      const delayedLabel = isDelayed ? ' [DELAYED]' : '';
                      return (
                        <SelectItem 
                          key={j.id} 
                          value={String(j.id)}
                          className="font-mono text-xs text-[#f0f0f5] focus:bg-[#1e1e2e] focus:text-[#f0f0f5]"
                        >
                          {j.refType === 'vessel' ? 'VES' : 'SO'}: {j.ref} | {j.mat} {j.sz}mm | {j.qty} pcs{progressText}{sharedLabel}{delayedLabel}
                        </SelectItem>
                      );
                    })}
                  </SelectContent>
                </Select>
              </div>
            ) : job ? (
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <span className="font-display text-xl tracking-wider text-[#f0f0f5]">
                    {job.refType === 'vessel' ? 'VES' : 'SO'}: {job.ref}
                  </span>
                </div>
                <div className="flex flex-wrap gap-2">
                  <Badge className={`${
                    job.mat === 'Viton' ? 'bg-orange-500/10 text-orange-400 border-orange-500/30' :
                    job.mat === 'Buna' ? 'bg-sky-500/10 text-sky-400 border-sky-500/30' :
                    'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                  } border font-mono text-[9px]`}>
                    {job.mat}
                  </Badge>
                  <span className="font-mono text-[10px] text-[#7a7a96]">{job.sz}mm</span>
                  <span className="font-mono text-[10px] text-[#7a7a96]">{job.qty} pcs</span>
                  <Badge variant="outline" className="font-mono text-[9px] border-orange-500/30 text-orange-400">
                    {press.dur}s
                  </Badge>
                </div>
                {job.md && (
                  <div className="font-mono text-[10px] text-orange-400">
                    Cut: {(job.md * Math.PI).toFixed(3)}"
                  </div>
                )}
                {job.qty > 1 && (
                  <div className="mt-3">
                    <div className="flex justify-between text-[10px] font-mono text-emerald-400 mb-1">
                      <span>CYCLE {Math.min(job.cyclesDone + 1, job.qty)} OF {job.qty}</span>
                      <span>{Math.round(cycleProgress)}% DONE</span>
                    </div>
                    <div className="h-1.5 bg-[#1e1e2e] rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-emerald-500 rounded-full transition-all duration-300"
                        style={{ width: `${cycleProgress}%` }}
                      />
                    </div>
                  </div>
                )}
              </div>
            ) : null}
          </div>

          {/* Timer Display */}
          <div className="text-center py-2">
            <motion.div 
              className={`font-display text-6xl sm:text-7xl tracking-[0.1em] ${
                press.run ? 'text-orange-400' : 
                press.done ? 'text-emerald-400' : 
                remaining <= 10 && press.run ? 'text-amber-400 animate-timer-warning' :
                'text-[#f0f0f5]'
              }`}
              animate={press.run ? { textShadow: '0 0 40px rgba(255, 69, 0, 0.3)' } : {}}
            >
              {timeDisplay}
            </motion.div>
          </div>

          {/* Progress Bar */}
          <div className="h-2 bg-[#1e1e2e] rounded-full overflow-hidden">
            <motion.div
              className={`h-full rounded-full ${
                press.done ? 'bg-emerald-500' : 'bg-gradient-to-r from-orange-500 to-orange-400'
              }`}
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.3, ease: 'linear' }}
            />
          </div>

          {/* Control Buttons */}
          {!press.done ? (
            <div className="grid grid-cols-3 gap-2">
              <Button
                onClick={onStart}
                disabled={!press.jobId || press.run}
                className="bg-orange-500 hover:bg-orange-600 text-white disabled:opacity-30"
              >
                <Play className="w-4 h-4 mr-1" />
                START
              </Button>
              <Button
                onClick={onReset}
                disabled={!press.run}
                variant="outline"
                className="border-[#2a2a3d] text-[#7a7a96] hover:text-[#f0f0f5] hover:bg-[#16161f] disabled:opacity-30"
              >
                <RotateCcw className="w-4 h-4 mr-1" />
                RESET
              </Button>
              <Button
                onClick={onUnload}
                disabled={press.run || !press.jobId}
                variant="outline"
                className="border-[#2a2a3d] text-[#7a7a96] hover:text-[#f0f0f5] hover:bg-[#16161f] disabled:opacity-30"
              >
                <LogOut className="w-4 h-4 mr-1" />
                UNLOAD
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-4 gap-2">
              <Button
                onClick={onNextCycle}
                disabled={job ? (job.cyclesDone || 0) >= job.qty : false}
                className="bg-orange-500 hover:bg-orange-600 text-white disabled:opacity-30"
              >
                <SkipForward className="w-4 h-4 mr-1" />
                NEXT
              </Button>
              <Button
                onClick={onRedoCycle}
                variant="outline"
                className="border-rose-500/30 text-rose-400 hover:bg-rose-500/10"
              >
                <Redo className="w-4 h-4 mr-1" />
                REDO
              </Button>
              <Button
                onClick={onCloseJob}
                className="bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/20"
              >
                <CheckCircle className="w-4 h-4 mr-1" />
                CLOSE
              </Button>
              <Button
                onClick={() => setDelayDialogOpen(true)}
                variant="outline"
                className="border-amber-500/30 text-amber-400 hover:bg-amber-500/10"
              >
                <Pause className="w-4 h-4 mr-1" />
                DELAY
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Delay Dialog */}
      <Dialog open={delayDialogOpen} onOpenChange={setDelayDialogOpen}>
        <DialogContent className="bg-[#0a0a0f] border-[#1e1e2e]">
          <DialogHeader>
            <DialogTitle className="font-display text-xl text-amber-400 tracking-wider">
              MARK DELAYED
            </DialogTitle>
            <DialogDescription className="font-mono text-sm text-[#7a7a96]">
              Job will remain in the queue with a DELAYED status so the next shift can pick it up.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            <div className="space-y-2">
              <Label className="font-mono text-[10px] tracking-wider text-[#7a7a96] uppercase">
                Reason for Delay
              </Label>
              <Input
                value={delayReason}
                onChange={(e) => setDelayReason(e.target.value)}
                placeholder="e.g. Material ran out, press issue, end of shift..."
                className="bg-[#16161f] border-[#2a2a3d] text-[#f0f0f5] font-mono text-sm"
              />
            </div>
            <Button
              onClick={handleDelayConfirm}
              className="w-full bg-amber-500/10 border border-amber-500/30 text-amber-400 hover:bg-amber-500/20"
            >
              CONFIRM DELAY
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

export function Presses({ 
  state, 
  notify, 
  addActivity, 
  updatePress, 
  addPressLogEntry,
  updateJob,
  incrementStat,
  deletePressLogEntry 
}: PressesProps) {
  const [intervals, setIntervals] = useState<Record<number, ReturnType<typeof setInterval> | null>>({ 1: null, 2: null });

  // Cleanup intervals on unmount
  useEffect(() => {
    return () => {
      Object.values(intervals).forEach(interval => {
        if (interval) clearInterval(interval);
      });
    };
  }, [intervals]);

  const getAvailableJobs = (pressNum: 1 | 2) => {
    return state.jobs.filter(j => 
      j.status === 'pending' || 
      j.status === 'delayed' || 
      (j.status === 'in-progress' && state.presses[pressNum].jobId !== j.id)
    );
  };

  const getJobForPress = (pressNum: 1 | 2) => {
    return state.jobs.find(j => j.id === state.presses[pressNum].jobId) || null;
  };

  const startPressTimer = (pressNum: 1 | 2) => {
    const press = state.presses[pressNum];
    if (press.run || !press.jobId) return;

    updatePress(pressNum, { run: true, done: false, el: 0 });

    const interval = setInterval(() => {
      const currentPress = state.presses[pressNum];
      const newEl = currentPress.el + 1;
      const remaining = currentPress.dur - newEl;

      if (remaining <= 0) {
        clearInterval(interval);
        completePressCycle(pressNum);
      } else {
        updatePress(pressNum, { el: newEl });
      }
    }, 1000);

    setIntervals(prev => ({ ...prev, [pressNum]: interval }));
  };

  const completePressCycle = (pressNum: 1 | 2) => {
    const press = state.presses[pressNum];
    const job = state.jobs.find(j => j.id === press.jobId);

    // Increment cycle count
    if (job) {
      const newCyclesDone = (job.cyclesDone || 0) + 1;
      updateJob(job.id, { cyclesDone: newCyclesDone });
    }

    incrementStat('cyc');

    // Log entry
    const now = new Date();
    const ts = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    addPressLogEntry({
      time: ts,
      press: pressNum,
      ref: job?.ref || '--',
      mat: press.mat || '--',
      sz: press.sz ? `${press.sz}mm` : '--',
      dur: `${press.dur}s`,
      res: 'cycle',
    });

    addActivity(`Press ${pressNum} cycle — ${job ? `${job.ref} · ` : ''}${press.mat} ${press.sz}mm (${job ? `${job.cyclesDone || 0}/${job.qty}` : '1'})`);

    updatePress(pressNum, { run: false, done: true });

    const allDone = job && (job.cyclesDone || 0) + 1 >= job.qty;
    if (allDone) {
      notify(`All ${job.qty} pcs done on Press ${pressNum} — close the job!`, 'success');
    } else {
      notify(`Press ${pressNum} done — ${job ? `${(job.cyclesDone || 0) + 1}/${job.qty} pcs. Next or Close Job` : 'Cycle complete.'}`, 'success');
    }
  };

  const handleLoadJob = (pressNum: 1 | 2, jobId: number) => {
    const job = state.jobs.find(j => j.id === jobId);
    if (!job) return;

    const dur = (PRESS_TIMES[job.mat] && PRESS_TIMES[job.mat][job.sz]) || 240;
    
    updatePress(pressNum, {
      jobId,
      mat: job.mat,
      sz: job.sz,
      dur,
      el: 0,
      run: false,
      done: false,
    });

    // Update job status
    const otherPress = pressNum === 1 ? 2 : 1;
    const otherHasJob = state.presses[otherPress].jobId === jobId;
    updateJob(jobId, { 
      status: 'in-progress',
      pressNum: otherHasJob ? '1+2' : pressNum,
      cyclesDone: job.cyclesDone || 0,
    });

    notify(`Press ${pressNum} loaded — ${job.mat} ${job.sz}mm · ${dur}s · ${job.cyclesDone || 0}/${job.qty} done`, 'info');
  };

  const handleUnload = (pressNum: 1 | 2) => {
    const press = state.presses[pressNum];
    if (press.run) {
      notify('Stop the press before unloading', 'warning');
      return;
    }

    if (press.jobId) {
      const otherPress = pressNum === 1 ? 2 : 1;
      const otherHasJob = state.presses[otherPress].jobId === press.jobId;
      
      if (!otherHasJob) {
        updateJob(press.jobId, { status: 'pending', pressNum: undefined });
      } else {
        updateJob(press.jobId, { pressNum: otherPress });
      }
    }

    updatePress(pressNum, { jobId: null, mat: '', sz: '', el: 0, run: false, done: false });
    notify(`Press ${pressNum} unloaded`, 'info');
  };

  const handleReset = (pressNum: 1 | 2) => {
    const interval = intervals[pressNum];
    if (interval) {
      clearInterval(interval);
      setIntervals(prev => ({ ...prev, [pressNum]: null }));
    }

    const press = state.presses[pressNum];
    let dur = 240;
    if (press.jobId) {
      const job = state.jobs.find(j => j.id === press.jobId);
      if (job) {
        dur = (PRESS_TIMES[job.mat] && PRESS_TIMES[job.mat][job.sz]) || 240;
      }
    }

    updatePress(pressNum, { run: false, done: false, el: 0, dur });
  };

  const handleNextCycle = (pressNum: 1 | 2) => {
    const press = state.presses[pressNum];
    const job = state.jobs.find(j => j.id === press.jobId);
    
    if (!job) return;
    if ((job.cyclesDone || 0) >= job.qty) {
      notify('All pieces already logged — close the job', 'warning');
      return;
    }

    updatePress(pressNum, { done: false, el: 0 });
    startPressTimer(pressNum);
  };

  const handleRedoCycle = (pressNum: 1 | 2) => {
    const press = state.presses[pressNum];
    const job = state.jobs.find(j => j.id === press.jobId);
    
    const now = new Date();
    const ts = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    
    addPressLogEntry({
      time: ts,
      press: pressNum,
      ref: job?.ref || '--',
      mat: press.mat || '--',
      sz: press.sz ? `${press.sz}mm` : '--',
      dur: `${press.dur}s`,
      res: 'redo',
    });

    addActivity(`Press ${pressNum} REDO — ${job ? job.ref : ''}${press.mat ? ` · ${press.mat} ${press.sz}mm` : ''}`);
    notify(`Press ${pressNum} — ring going back through. Cycle count unchanged.`, 'warning');
    
    updatePress(pressNum, { done: false, el: 0 });
    startPressTimer(pressNum);
  };

  const handleCloseJob = (pressNum: 1 | 2) => {
    const press = state.presses[pressNum];
    const job = state.jobs.find(j => j.id === press.jobId);
    
    if (job) {
      const credited = job.cyclesDone || 0;
      incrementStat('out', credited);
      
      // Update material stats
      const currentMatCount = state.stats.mat[job.mat] || 0;
      state.stats.mat[job.mat] = currentMatCount + credited;
    }

    const now = new Date();
    const ts = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    
    addPressLogEntry({
      time: ts,
      press: pressNum,
      ref: job?.ref || '--',
      mat: press.mat || '--',
      sz: press.sz ? `${press.sz}mm` : '--',
      dur: `${press.dur}s`,
      res: 'complete',
    });

    addActivity(`Press ${pressNum} — ${job ? job.ref : 'job'} CLOSED (${job ? job.cyclesDone : 0}/${job ? job.qty : '?'}) pcs`);

    if (job) {
      const otherPress = pressNum === 1 ? 2 : 1;
      if (state.presses[otherPress].jobId === job.id) {
        updatePress(otherPress, { jobId: null, mat: '', sz: '', el: 0, run: false, done: false });
      }
      updateJob(job.id, { status: 'done', pressNum: undefined });
    }

    updatePress(pressNum, { jobId: null, mat: '', sz: '', el: 0, run: false, done: false });
    notify(`Job closed — ${job ? `${job.cyclesDone} pcs logged` : ''}`, 'success');
  };

  const handleDelay = (pressNum: 1 | 2, reason: string) => {
    const press = state.presses[pressNum];
    const job = state.jobs.find(j => j.id === press.jobId);
    
    if (job) {
      const credited = job.cyclesDone || 0;
      incrementStat('out', credited);
      state.stats.mat[job.mat] = (state.stats.mat[job.mat] || 0) + credited;
      
      const otherPress = pressNum === 1 ? 2 : 1;
      if (state.presses[otherPress].jobId === job.id) {
        updatePress(otherPress, { jobId: null, mat: '', sz: '', el: 0, run: false, done: false });
      }
      
      updateJob(job.id, { status: 'delayed', delayReason: reason, pressNum: undefined });
    }

    const now = new Date();
    const ts = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    
    addPressLogEntry({
      time: ts,
      press: pressNum,
      ref: job?.ref || '--',
      mat: press.mat || '--',
      sz: press.sz ? `${press.sz}mm` : '--',
      dur: `${press.dur}s`,
      res: 'delayed',
    });

    addActivity(`Press ${pressNum} — ${job ? job.ref : ''} DELAYED: ${reason}`);
    notify('Job delayed — back in queue', 'warning');

    updatePress(pressNum, { jobId: null, mat: '', sz: '', el: 0, run: false, done: false });
  };

  return (
    <div className="space-y-6">
      {/* Press Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {[1, 2].map((pressNum) => (
          <PressCard
            key={pressNum}
            pressNum={pressNum as 1 | 2}
            press={state.presses[pressNum as 1 | 2]}
            job={getJobForPress(pressNum as 1 | 2)}
            availableJobs={getAvailableJobs(pressNum as 1 | 2)}
            onLoadJob={(jobId) => handleLoadJob(pressNum as 1 | 2, jobId)}
            onUnload={() => handleUnload(pressNum as 1 | 2)}
            onStart={() => startPressTimer(pressNum as 1 | 2)}
            onReset={() => handleReset(pressNum as 1 | 2)}
            onNextCycle={() => handleNextCycle(pressNum as 1 | 2)}
            onRedoCycle={() => handleRedoCycle(pressNum as 1 | 2)}
            onCloseJob={() => handleCloseJob(pressNum as 1 | 2)}
            onDelay={(reason) => handleDelay(pressNum as 1 | 2, reason)}
          />
        ))}
      </div>

      {/* Press Log */}
      <Card className="bg-gradient-to-br from-[#0a0a0f] to-[#101018] border-[#1e1e2e]">
        <CardHeader>
          <CardTitle className="font-display text-lg tracking-wider text-[#7a7a96]">
            TODAY'S PRESS LOG
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#1e1e2e]">
                  <th className="text-left py-2 px-3 font-mono text-[9px] tracking-[0.2em] text-[#7a7a96] uppercase">Time</th>
                  <th className="text-left py-2 px-3 font-mono text-[9px] tracking-[0.2em] text-[#7a7a96] uppercase">Press</th>
                  <th className="text-left py-2 px-3 font-mono text-[9px] tracking-[0.2em] text-[#7a7a96] uppercase">Reference</th>
                  <th className="text-left py-2 px-3 font-mono text-[9px] tracking-[0.2em] text-[#7a7a96] uppercase">Material</th>
                  <th className="text-left py-2 px-3 font-mono text-[9px] tracking-[0.2em] text-[#7a7a96] uppercase">Size</th>
                  <th className="text-left py-2 px-3 font-mono text-[9px] tracking-[0.2em] text-[#7a7a96] uppercase">Duration</th>
                  <th className="text-left py-2 px-3 font-mono text-[9px] tracking-[0.2em] text-[#7a7a96] uppercase">Result</th>
                  <th className="text-left py-2 px-3 font-mono text-[9px] tracking-[0.2em] text-[#7a7a96] uppercase"></th>
                </tr>
              </thead>
              <tbody>
                {state.pLog.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-8 text-center font-mono text-[10px] text-[#3d3d55]">
                      No cycles logged yet.
                    </td>
                  </tr>
                ) : (
                  state.pLog.slice(0, 50).map((entry, i) => {
                    const matChar = entry.mat.toLowerCase().charAt(0);
                    const resultColor = 
                      entry.res === 'complete' ? 'text-emerald-400 border-emerald-500/30 bg-emerald-500/10' :
                      entry.res === 'delayed' ? 'text-amber-400 border-amber-500/30 bg-amber-500/10' :
                      entry.res === 'cycle' ? 'text-orange-400 border-orange-500/30 bg-orange-500/10' :
                      entry.res === 'redo' ? 'text-sky-400 border-sky-500/30 bg-sky-500/10' :
                      'text-rose-400 border-rose-500/30 bg-rose-500/10';
                    
                    return (
                      <tr key={i} className="border-b border-[#1e1e2e]/50 hover:bg-[#16161f]/50 transition-colors">
                        <td className="py-2 px-3 font-mono text-[11px] text-[#f0f0f5]">{entry.time}</td>
                        <td className="py-2 px-3 font-mono text-[11px] text-[#f0f0f5]">Press {entry.press}</td>
                        <td className="py-2 px-3 font-mono text-[11px] text-[#f0f0f5]">{entry.ref}</td>
                        <td className="py-2 px-3">
                          <Badge className={`${
                            matChar === 'v' ? 'bg-orange-500/10 text-orange-400 border-orange-500/30' :
                            matChar === 'b' ? 'bg-sky-500/10 text-sky-400 border-sky-500/30' :
                            'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                          } border font-mono text-[9px]`}>
                            {entry.mat}
                          </Badge>
                        </td>
                        <td className="py-2 px-3 font-mono text-[11px] text-[#f0f0f5]">{entry.sz}</td>
                        <td className="py-2 px-3 font-mono text-[11px] text-[#f0f0f5]">{entry.dur}</td>
                        <td className="py-2 px-3">
                          <Badge variant="outline" className={`${resultColor} font-mono text-[9px] uppercase`}>
                            {entry.res}
                          </Badge>
                        </td>
                        <td className="py-2 px-3">
                          <button
                            onClick={() => deletePressLogEntry(i)}
                            className="text-[#3d3d55] hover:text-rose-400 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
