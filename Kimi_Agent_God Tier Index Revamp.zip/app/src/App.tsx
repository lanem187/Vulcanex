import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Toaster, toast } from 'sonner';
import { 
  LayoutDashboard, 
  Cog, 
  ListTodo, 
  ClipboardList, 
  Calculator, 
  AlertTriangle, 
  Package, 
  Search,
  Menu,
  Clock
} from 'lucide-react';
import { useAppState } from '@/hooks/useAppState';
import { Dashboard } from '@/sections/Dashboard';
import { Presses } from '@/sections/Presses';
import { JobQueue } from '@/sections/JobQueue';
import { Handoff } from '@/sections/Handoff';
import { CutLengthCalc } from '@/sections/CutLengthCalc';
import { ScrapLog } from '@/sections/ScrapLog';
import { Inventory } from '@/sections/Inventory';
import { Parts } from '@/sections/Parts';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';

export type TabId = 'dashboard' | 'presses' | 'jobs' | 'handoff' | 'calc' | 'scrap' | 'inventory' | 'parts';

interface Tab {
  id: TabId;
  label: string;
  icon: React.ElementType;
}

const tabs: Tab[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'presses', label: 'Presses', icon: Cog },
  { id: 'jobs', label: 'Job Queue', icon: ListTodo },
  { id: 'handoff', label: 'Handoff', icon: ClipboardList },
  { id: 'calc', label: 'Cut Length', icon: Calculator },
  { id: 'scrap', label: 'Scrap Log', icon: AlertTriangle },
  { id: 'inventory', label: 'Inventory', icon: Package },
  { id: 'parts', label: 'Parts', icon: Search },
];

function App() {
  const [activeTab, setActiveTab] = useState<TabId>('dashboard');
  const [currentTime, setCurrentTime] = useState(new Date());
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  const appState = useAppState();
  const { state, isLoaded } = appState;

  // Clock update
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Notify helper
  const notify = useCallback((message: string, type: 'success' | 'error' | 'warning' | 'info' = 'info') => {
    const styles = {
      success: { icon: '✓', className: 'border-emerald-500/30 bg-emerald-500/10' },
      error: { icon: '✕', className: 'border-rose-500/30 bg-rose-500/10' },
      warning: { icon: '⚠', className: 'border-amber-500/30 bg-amber-500/10' },
      info: { icon: 'ℹ', className: 'border-orange-500/30 bg-orange-500/10' },
    };
    const style = styles[type];
    
    toast(message, {
      icon: style.icon,
      className: `${style.className} border backdrop-blur-sm`,
      duration: 4000,
    });
  }, []);

  // Activity tracker
  const addActivity = useCallback((message: string) => {
    appState.addActivity(message);
  }, [appState]);

  const formatTime = (date: Date) => {
    return `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}:${String(date.getSeconds()).padStart(2, '0')}`;
  };

  const renderTabContent = () => {
    const commonProps = { 
      state, 
      notify, 
      addActivity,
      updatePress: appState.updatePress,
      addPressLogEntry: appState.addPressLogEntry,
      deletePressLogEntry: appState.deletePressLogEntry,
      addJob: appState.addJob,
      updateJob: appState.updateJob,
      removeJob: appState.removeJob,
      addScrap: appState.addScrap,
      deleteScrap: appState.deleteScrap,
      addCalc: appState.addCalc,
      addHandoff: appState.addHandoff,
      updateInventory: appState.updateInventory,
      addPart: appState.addPart,
      incrementStat: appState.incrementStat,
      incrementMaterialStat: appState.incrementMaterialStat,
      setRefType: appState.setRefType,
      clearCategory: appState.clearCategory,
      clearAll: appState.clearAll,
    };

    switch (activeTab) {
      case 'dashboard':
        return <Dashboard {...commonProps} />;
      case 'presses':
        return <Presses {...commonProps} />;
      case 'jobs':
        return <JobQueue {...commonProps} />;
      case 'handoff':
        return <Handoff {...commonProps} />;
      case 'calc':
        return <CutLengthCalc {...commonProps} />;
      case 'scrap':
        return <ScrapLog {...commonProps} />;
      case 'inventory':
        return <Inventory {...commonProps} />;
      case 'parts':
        return <Parts {...commonProps} />;
      default:
        return <Dashboard {...commonProps} />;
    }
  };

  if (!isLoaded) {
    return (
      <div className="min-h-screen bg-[#050507] flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-2 border-orange-500/30 border-t-orange-500 rounded-full animate-spin" />
          <span className="text-[#7a7a96] font-mono text-sm tracking-wider">INITIALIZING VULCANEX...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#050507] text-[#f0f0f5] relative">
      <Toaster 
        position="top-right" 
        toastOptions={{
          style: {
            background: 'rgba(16, 16, 24, 0.95)',
            border: '1px solid rgba(46, 46, 62, 0.8)',
            color: '#f0f0f5',
          },
        }}
      />

      {/* Header */}
      <header className="sticky top-0 z-50 glass border-b border-[#1e1e2e]">
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-baseline gap-3">
              <h1 className="font-display text-2xl sm:text-3xl text-[#ff4500] tracking-[0.2em] relative">
                VULCANEX
                <span className="absolute -bottom-1 left-0 right-0 h-[2px] bg-gradient-to-r from-[#ff4500] via-[#ff6a00] to-transparent rounded-full" />
              </h1>
              <span className="hidden sm:inline text-[9px] tracking-[0.25em] text-[#3d3d55] uppercase font-mono">
                Fil-Trek Production Intelligence
              </span>
            </div>

            {/* Desktop: Right side info */}
            <div className="hidden md:flex items-center gap-4">
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span className="font-mono text-[10px] tracking-wider text-emerald-400 uppercase">
                  Day · 07:30–16:30
                </span>
              </div>
              <div className="font-mono text-sm text-[#7a7a96] tracking-wider min-w-[70px] text-right">
                {formatTime(currentTime)}
              </div>
            </div>

            {/* Mobile menu button */}
            <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
              <SheetTrigger asChild className="md:hidden">
                <Button variant="ghost" size="icon" className="text-[#f0f0f5]">
                  <Menu className="w-6 h-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[280px] bg-[#0a0a0f] border-l border-[#1e1e2e] p-0">
                <div className="flex flex-col h-full">
                  <div className="p-4 border-b border-[#1e1e2e]">
                    <div className="flex items-center justify-between">
                      <span className="font-display text-xl text-[#ff4500] tracking-wider">MENU</span>
                    </div>
                  </div>
                  <nav className="flex-1 p-2">
                    {tabs.map((tab) => {
                      const Icon = tab.icon;
                      return (
                        <button
                          key={tab.id}
                          onClick={() => {
                            setActiveTab(tab.id);
                            setMobileMenuOpen(false);
                          }}
                          className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left transition-all duration-200 ${
                            activeTab === tab.id
                              ? 'bg-[#ff4500]/10 text-[#ff4500] border border-[#ff4500]/30'
                              : 'text-[#7a7a96] hover:text-[#f0f0f5] hover:bg-[#16161f]'
                          }`}
                        >
                          <Icon className="w-5 h-5" />
                          <span className="font-mono text-xs tracking-wider uppercase">{tab.label}</span>
                        </button>
                      );
                    })}
                  </nav>
                  <div className="p-4 border-t border-[#1e1e2e]">
                    <div className="flex items-center gap-2 text-[#7a7a96]">
                      <Clock className="w-4 h-4" />
                      <span className="font-mono text-sm">{formatTime(currentTime)}</span>
                    </div>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </header>

      {/* Navigation - Desktop */}
      <nav className="hidden md:block sticky top-16 z-40 bg-[#0a0a0f]/95 backdrop-blur-sm border-b border-[#1e1e2e]">
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-1 overflow-x-auto scrollbar-hide py-1">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`relative flex items-center gap-2 px-4 py-3 font-mono text-[10px] tracking-[0.2em] uppercase whitespace-nowrap transition-all duration-200 rounded-md ${
                    isActive
                      ? 'text-[#ff4500]'
                      : 'text-[#7a7a96] hover:text-[#f0f0f5]'
                  }`}
                >
                  {isActive && (
                    <motion.div
                      layoutId="activeTab"
                      className="absolute inset-0 bg-[#ff4500]/10 border border-[#ff4500]/30 rounded-md"
                      transition={{ type: 'spring', bounce: 0.2, duration: 0.6 }}
                    />
                  )}
                  <span className="relative z-10 flex items-center gap-2">
                    <Icon className="w-4 h-4" />
                    {tab.label}
                  </span>
                  {isActive && (
                    <motion.div
                      layoutId="activeTabBorder"
                      className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#ff4500]"
                      transition={{ type: 'spring', bounce: 0.2, duration: 0.6 }}
                    />
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </nav>

      {/* Mobile Tab Bar */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-[#0a0a0f]/95 backdrop-blur-lg border-t border-[#1e1e2e] safe-area-pb">
        <div className="flex items-center justify-around px-2 py-2">
          {tabs.slice(0, 5).map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex flex-col items-center gap-1 px-3 py-2 rounded-lg transition-all duration-200 ${
                  isActive
                    ? 'text-[#ff4500]'
                    : 'text-[#7a7a96]'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-[9px] font-mono uppercase tracking-wider">{tab.label.slice(0, 6)}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-24 md:pb-6">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
          >
            {renderTabContent()}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}

export default App;
